import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { D as FileDown, F as CircleCheckBig, N as CirclePlay, h as MessageSquare } from "../_libs/lucide-react.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learning-Bt_V1QJ4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LearningPage() {
	const { user } = useAuth();
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [answer, setAnswer] = (0, import_react.useState)("");
	const [discussion, setDiscussion] = (0, import_react.useState)("");
	async function saveProgress(value) {
		setProgress(value);
		if (user) await supabase.from("course_progress").upsert({
			user_id: user.id,
			product_id: "00000000-0000-0000-0000-000000000000",
			lesson_id: "demo",
			progress: value,
			completed_at: value === 100 ? (/* @__PURE__ */ new Date()).toISOString() : null
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold",
				children: "مساحة التعلم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "مشغل فيديو جاهز للربط بتخزين خاص، مع حفظ التقدم والاختبارات."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 aspect-video rounded-2xl bg-slate-950 p-6 text-center text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "mx-auto mt-16 h-16 w-16 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: "Video player placeholder — أضف رابط الفيديو الموقّع من الخادم"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تقدم الدرس" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [progress, "%"] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-3 rounded-full bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-3 rounded-full bg-primary transition-all",
							style: { width: `${progress}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-3 w-full",
						type: "range",
						value: progress,
						onChange: (e) => saveProgress(Number(e.target.value))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 grid gap-6 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "flex items-center gap-2 font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5 text-primary" }), "اختبار قصير"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4",
							children: "ما أفضل ممارسة لحماية ملفات الفيديو؟"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "q",
								value: "signed",
								onChange: (e) => setAnswer(e.target.value)
							}), " روابط موقعة قصيرة"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-2 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "q",
								value: "public",
								onChange: (e) => setAnswer(e.target.value)
							}), " رابط عام دائم"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm",
							children: answer && (answer === "signed" ? "إجابة صحيحة" : "حاول مرة أخرى")
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "flex items-center gap-2 font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-5 w-5 text-primary" }), "مناقشة الدرس"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: discussion,
							onChange: (e) => setDiscussion(e.target.value),
							className: "mt-4 min-h-24 w-full rounded-lg border p-3",
							placeholder: "اكتب سؤالك"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								if (user && discussion) supabase.from("lesson_discussions").insert({
									product_id: "00000000-0000-0000-0000-000000000000",
									lesson_id: "demo",
									user_id: user.id,
									body: discussion
								});
								setDiscussion("");
							},
							className: "mt-2 rounded-lg bg-primary px-4 py-2 text-primary-foreground",
							children: "نشر"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => window.print(),
				className: "mt-8 inline-flex items-center gap-2 rounded-xl border px-4 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "h-4 w-4" }), "طباعة شهادة الإتمام"]
			})
		]
	});
}
//#endregion
export { LearningPage as component };
