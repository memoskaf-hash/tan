import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-DtErqdQ0.js
var $$splitComponentImporter = () => import("./auth-DIqy65_V.mjs");
var Route = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "تسجيل الدخول | جود" },
		{
			name: "description",
			content: "سجّل دخولك لإتمام مشترياتك والوصول إلى منتجاتك الرقمية."
		},
		{
			property: "og:title",
			content: "تسجيل الدخول | جود"
		},
		{
			property: "og:description",
			content: "سجّل دخولك لإتمام مشترياتك والوصول إلى منتجاتك الرقمية."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	validateSearch: (search) => ({ redirect: typeof search["redirect"] === "string" ? search["redirect"] : "/" }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
