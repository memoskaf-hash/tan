import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/content-CJJ4hQYH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fallback = [{
	slug: "welcome",
	title: "مرحباً بك في أكاديمية المتجر",
	body: "مقالات ودروس عملية تُحدّث باستمرار."
}, {
	slug: "faq",
	title: "الأسئلة الشائعة",
	body: "يمكنك الوصول إلى مشترياتك مدى الحياة. تواصل معنا لطلبات الاسترداد."
}];
function ContentPage() {
	const [pages, setPages] = (0, import_react.useState)(fallback);
	(0, import_react.useEffect)(() => {
		supabase.from("content_pages").select("slug,title,body").eq("published", true).order("updated_at", { ascending: false }).then(({ data }) => data?.length && setPages(data));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl px-4 py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl font-bold",
			children: "المقالات والأسئلة الشائعة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 space-y-5",
			children: pages.map((page) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border bg-card p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold",
					children: page.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 whitespace-pre-wrap text-muted-foreground",
					children: page.body
				})]
			}, page.slug))
		})]
	});
}
//#endregion
export { ContentPage as component };
