import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { C as Link2, E as Gift, O as ExternalLink, j as Copy, m as MousePointerClick, r as Wallet } from "../_libs/lucide-react.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/affiliate-Bd1BsTcU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AffiliatePage() {
	const { user } = useAuth();
	const [referral, setReferral] = (0, import_react.useState)(null);
	const [vendor, setVendor] = (0, import_react.useState)(null);
	const [products, setProducts] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		(async () => {
			const client = supabase;
			const [{ data: ref }, { data: ven }, { data: catalog }] = await Promise.all([
				client.from("referrals").select("*").eq("affiliate_id", user.id).eq("status", "active").maybeSingle(),
				client.from("vendors").select("id,business_name,status,payout_currency").eq("user_id", user.id).maybeSingle(),
				client.from("products").select("id,title,price,slug").limit(12)
			]);
			setReferral(ref);
			setVendor(ven);
			setProducts(catalog ?? []);
		})();
	}, [user]);
	async function createReferral() {
		if (!user) return;
		setBusy(true);
		const session = await supabase.auth.getSession();
		const response = await fetch("/api/affiliate-referral", {
			method: "POST",
			headers: { Authorization: `Bearer ${session.data.session?.access_token ?? ""}` }
		});
		const result = await response.json();
		setBusy(false);
		if (!response.ok) alert("تعذر إنشاء الرابط حالياً. قد يكون لديك رابط موجود بالفعل.");
		else setReferral(result.referral);
	}
	const link = referral && `${window.location.origin}/?ref=${encodeURIComponent(referral.code)}`;
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-10 w-10 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 text-3xl font-bold",
				children: "شراكات البائعين"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 rounded-xl bg-muted p-4",
				children: "سجّل الدخول لعرض لوحة الشراكة الخاصة بك."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-primary",
						children: "Vendor / Affiliate Partnership"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-bold",
						children: "لوحة الشراكة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted-foreground",
						children: "روابط آمنة، إحالة موثوقة، واحتساب عمولات من الخادم فقط."
					})
				] }), vendor && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full border px-3 py-1 text-sm",
					children: [
						vendor.business_name,
						" · ",
						vendor.status
					]
				})]
			}),
			!referral ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-2xl border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-semibold",
						children: "ابدأ التسويق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted-foreground",
						children: "أنشئ رابط إحالة فريد لمشاركة المنتجات."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						onClick: createReferral,
						className: "mt-5 rounded-xl bg-primary px-5 py-3 text-primary-foreground",
						children: busy ? "جارٍ الإنشاء..." : "إنشاء رابط الإحالة"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-2xl border bg-card p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: [
							"رابطك (وكود الخصم: ",
							referral.code,
							")"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						dir: "ltr",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							readOnly: true,
							value: link ?? "",
							className: "min-w-0 flex-1 rounded-lg border bg-muted p-3"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "نسخ الرابط",
							onClick: () => navigator.clipboard.writeText(link ?? ""),
							className: "rounded-lg border p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MousePointerClick, {}),
							label: "النقرات",
							value: referral.clicks ?? 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {}),
							label: "التحويلات",
							value: referral.conversions ?? 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {}),
							label: "الأرباح المعلّقة",
							value: `${vendor?.payout_currency ?? "USD"} ${Number(referral.earnings ?? 0).toFixed(2)}`
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-semibold",
						children: "المنتجات المتاحة للترويج"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-xl border p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: product.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: ["$", product.price]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "rounded-lg border p-2",
								href: `${link}&product=${product.slug}`,
								target: "_blank",
								rel: "noreferrer",
								"aria-label": "فتح رابط المنتج",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4" })
							})]
						}, product.id))
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-xs text-muted-foreground",
				children: "العمولة تتدرج تلقائياً: خصم المنصة 15% أساساً، 12% عند 101–500، و8% بعد 501. تتم مراجعة الاستردادات والاحتيال قبل الدفع."
			})
		]
	});
}
function Metric({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-primary",
			children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted-foreground",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "mt-3 block text-2xl",
			children: value
		})]
	});
}
//#endregion
export { AffiliatePage as component };
