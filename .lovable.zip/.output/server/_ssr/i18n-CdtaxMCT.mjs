import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/i18n-CdtaxMCT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LANGUAGES = {
	ar: "العربية",
	en: "English",
	fr: "Français",
	es: "Español",
	nl: "Nederlands",
	de: "Deutsch",
	sv: "Svenska"
};
var dictionaries = {
	ar: {
		home: "الرئيسية",
		courses: "الكورسات",
		about: "من نحن",
		contact: "تواصل معنا",
		cart: "السلة",
		purchases: "مشترياتي",
		login: "دخول",
		logout: "تسجيل الخروج",
		profile: "الملف الشخصي",
		admin: "الإدارة",
		secure: "دفع آمن",
		search: "ابحث عن منتج أو كورس...",
		details: "التفاصيل",
		digital: "منتج رقمي",
		course: "كورس تدريبي",
		add: "أضف إلى السلة",
		inCart: "في السلة",
		noResults: "لا توجد نتائج مطابقة لبحثك.",
		chat: "مساعد المتجر",
		send: "إرسال"
	},
	en: {
		home: "Home",
		courses: "Courses",
		about: "About",
		contact: "Contact",
		cart: "Cart",
		purchases: "My purchases",
		login: "Login",
		logout: "Log out",
		profile: "Profile",
		admin: "Admin",
		secure: "Secure payment",
		search: "Search products or courses...",
		details: "Details",
		digital: "Digital product",
		course: "Training course",
		add: "Add to cart",
		inCart: "In cart",
		noResults: "No matching results.",
		chat: "Store assistant",
		send: "Send"
	},
	fr: {
		home: "Accueil",
		courses: "Cours",
		about: "À propos",
		contact: "Contact",
		cart: "Panier",
		purchases: "Mes achats",
		login: "Connexion",
		logout: "Déconnexion",
		profile: "Profil",
		admin: "Administration",
		secure: "Paiement sécurisé",
		search: "Rechercher...",
		details: "Détails",
		digital: "Produit numérique",
		course: "Cours",
		add: "Ajouter au panier",
		inCart: "Dans le panier",
		noResults: "Aucun résultat.",
		chat: "Assistant",
		send: "Envoyer"
	},
	es: {
		home: "Inicio",
		courses: "Cursos",
		about: "Nosotros",
		contact: "Contacto",
		cart: "Carrito",
		purchases: "Mis compras",
		login: "Entrar",
		logout: "Salir",
		profile: "Perfil",
		admin: "Admin",
		secure: "Pago seguro",
		search: "Buscar...",
		details: "Detalles",
		digital: "Producto digital",
		course: "Curso",
		add: "Añadir",
		inCart: "En el carrito",
		noResults: "Sin resultados.",
		chat: "Asistente",
		send: "Enviar"
	},
	nl: {
		home: "Home",
		courses: "Cursussen",
		about: "Over ons",
		contact: "Contact",
		cart: "Winkelmand",
		purchases: "Mijn aankopen",
		login: "Inloggen",
		logout: "Uitloggen",
		profile: "Profiel",
		admin: "Beheer",
		secure: "Veilig betalen",
		search: "Zoeken...",
		details: "Details",
		digital: "Digitaal product",
		course: "Cursus",
		add: "Toevoegen",
		inCart: "In winkelmand",
		noResults: "Geen resultaten.",
		chat: "Assistent",
		send: "Versturen"
	},
	de: {
		home: "Startseite",
		courses: "Kurse",
		about: "Über uns",
		contact: "Kontakt",
		cart: "Warenkorb",
		purchases: "Meine Käufe",
		login: "Anmelden",
		logout: "Abmelden",
		profile: "Profil",
		admin: "Admin",
		secure: "Sichere Zahlung",
		search: "Suchen...",
		details: "Details",
		digital: "Digitales Produkt",
		course: "Kurs",
		add: "In den Warenkorb",
		inCart: "Im Warenkorb",
		noResults: "Keine Ergebnisse.",
		chat: "Assistent",
		send: "Senden"
	},
	sv: {
		home: "Hem",
		courses: "Kurser",
		about: "Om oss",
		contact: "Kontakt",
		cart: "Varukorg",
		purchases: "Mina köp",
		login: "Logga in",
		logout: "Logga ut",
		profile: "Profil",
		admin: "Admin",
		secure: "Säker betalning",
		search: "Sök...",
		details: "Detaljer",
		digital: "Digital produkt",
		course: "Kurs",
		add: "Lägg i varukorg",
		inCart: "I varukorgen",
		noResults: "Inga resultat.",
		chat: "Assistent",
		send: "Skicka"
	}
};
var I18nContext = (0, import_react.createContext)({
	language: "ar",
	setLanguage: () => {},
	t: (k) => dictionaries.ar[k] ?? k
});
function I18nProvider({ children }) {
	const [language, setLanguageState] = (0, import_react.useState)("ar");
	const setLanguage = (l) => {
		setLanguageState(l);
		localStorage.setItem("language", l);
	};
	(0, import_react.useEffect)(() => {
		const stored = localStorage.getItem("language");
		if (stored && stored in LANGUAGES) setLanguageState(stored);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = language;
		document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
	}, [language]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nContext.Provider, {
		value: {
			language,
			setLanguage,
			t: (key) => dictionaries[language][key] ?? dictionaries.ar[key] ?? key
		},
		children
	});
}
var useI18n = () => (0, import_react.useContext)(I18nContext);
//#endregion
export { LANGUAGES as n, useI18n as r, I18nProvider as t };
