import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-COR12J9L.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Admin() {
	const { user, loading } = useAuth();
	const [items, setItems] = (0, import_react.useState)([]);
	const [title, setTitle] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("0");
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [contentTitle, setContentTitle] = (0, import_react.useState)("");
	const [contentBody, setContentBody] = (0, import_react.useState)("");
	const authorized = user?.app_metadata?.role === "admin" || user?.app_metadata?.role === "super_admin";
	(0, import_react.useEffect)(() => {
		if (!loading && authorized) {
			supabase.from("products").select("*").then(({ data }) => setItems(data ?? []));
			supabase.from("orders").select("id,customer_name,total,status").order("created_at", { ascending: false }).then(({ data }) => setOrders(data ?? []));
		}
	}, [authorized, loading]);
	async function create() {
		const { data } = await supabase.from("products").insert({
			slug: title.toLowerCase().replace(/\s+/g, "-"),
			title,
			description: title,
			long_description: title,
			price: Number(price),
			type: "digital",
			features: [],
			curriculum: [],
			instructor: "Store",
			rating: 5,
			students: 0
		}).select().single();
		if (data) setItems([...items, data]);
		setTitle("");
	}
	async function remove(id) {
		await supabase.from("products").delete().eq("id", id);
		setItems(items.filter((x) => x.id !== id));
	}
	async function publishContent() {
		if (!contentTitle || !contentBody) return;
		const { error } = await supabase.from("content_pages").upsert({
			slug: contentTitle.toLowerCase().replace(/\s+/g, "-"),
			title: contentTitle,
			body: contentBody,
			published: true
		});
		if (!error) {
			setContentTitle("");
			setContentBody("");
			alert("تم نشر المحتوى");
		} else alert("تعذر النشر؛ شغّل migration المنصة أولاً.");
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-4xl px-4 py-12",
		children: "جارٍ التحقق من الصلاحيات…"
	});
	if (!authorized) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-4xl px-4 py-12 text-center text-destructive",
		children: "غير مصرح لك بالوصول إلى لوحة الإدارة."
	});
	const revenue = orders.filter((o) => o.status === "confirmed" || o.status === "paid").reduce((sum, o) => sum + Number(o.total), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mb-6 text-2xl font-bold",
				children: "لوحة الإدارة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted-foreground",
							children: "المنتجات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "mt-1 block text-2xl",
							children: items.length
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted-foreground",
							children: "الطلبات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "mt-1 block text-2xl",
							children: orders.length
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted-foreground",
							children: "المبيعات المؤكدة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "mt-1 block text-2xl",
							children: ["$", revenue.toFixed(2)]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-lg font-bold",
					children: "إدارة المنتجات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "اسم المنتج",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							className: "rounded-lg border p-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "السعر",
							value: price,
							onChange: (e) => setPrice(e.target.value),
							className: "w-24 rounded-lg border p-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: create,
							className: "rounded-lg bg-primary px-4 text-primary-foreground",
							children: "إضافة"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between rounded-lg border p-3",
						children: [item.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => remove(item.id),
							className: "text-destructive",
							children: "حذف"
						})]
					}, item.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-lg font-bold",
					children: "آخر الطلبات والعملاء"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-xl border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "العميل"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "المبلغ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "الحالة"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: order.customer_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: ["$", order.total]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: order.status
								})
							]
						}, order.id)) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 rounded-xl border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-lg font-bold",
						children: "تحرير المقالات والأسئلة الشائعة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: contentTitle,
						onChange: (e) => setContentTitle(e.target.value),
						placeholder: "العنوان",
						className: "mb-2 w-full rounded-lg border p-2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: contentBody,
						onChange: (e) => setContentBody(e.target.value),
						placeholder: "المحتوى",
						className: "min-h-28 w-full rounded-lg border p-2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: publishContent,
						className: "mt-2 rounded-lg bg-primary px-4 py-2 text-primary-foreground",
						children: "نشر الصفحة"
					})
				]
			})
		]
	});
}
//#endregion
export { Admin as component };
