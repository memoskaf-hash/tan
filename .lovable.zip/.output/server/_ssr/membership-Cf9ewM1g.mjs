import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as Crown, I as Check } from "../_libs/lucide-react.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/membership-Cf9ewM1g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fallbackPlans = [
	{
		id: "starter",
		name: "الأساسية",
		interval: "monthly",
		price: 9,
		entitlements: ["وصول للكورسات الأساسية", "نقاط ولاء شهرية"]
	},
	{
		id: "pro",
		name: "الاحترافية",
		interval: "monthly",
		price: 19,
		entitlements: [
			"كل الكورسات",
			"شهادة إتمام",
			"دعم وأولوية"
		]
	},
	{
		id: "annual",
		name: "السنوية",
		interval: "yearly",
		price: 190,
		entitlements: ["كل مزايا الاحترافية", "شهران مجاناً"]
	}
];
function MembershipPage() {
	const { user } = useAuth();
	const [plans, setPlans] = (0, import_react.useState)(fallbackPlans);
	(0, import_react.useEffect)(() => {
		supabase.from("membership_plans").select("*").eq("active", true).then(({ data }) => data?.length && setPlans(data));
	}, []);
	async function choose(plan) {
		if (!user) return alert("سجّل الدخول أولاً");
		const { error } = await supabase.from("memberships").insert({
			user_id: user.id,
			plan_id: plan.id,
			status: "pending"
		});
		alert(error ? "تعذر بدء الاشتراك. تحقق من إعداد Supabase." : "تم إرسال طلب الاشتراك للمراجعة؛ لم يتم تحصيل أي مبلغ.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "mx-auto h-10 w-10 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-3xl font-bold",
					children: "العضويات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted-foreground",
					children: "خطط شهرية وسنوية بصلاحيات واضحة. الدفع الفعلي يحتاج مزوداً خادمياً."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-10 grid gap-6 md:grid-cols-3",
			children: plans.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold",
						children: plan.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-3xl font-bold",
						children: [
							"$",
							plan.price,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
								className: "text-sm text-muted-foreground",
								children: ["/", plan.interval === "yearly" ? "سنة" : "شهر"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "my-6 space-y-3 text-sm",
						children: (plan.entitlements || []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-primary" }), e]
						}, e))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => choose(plan),
						className: "w-full rounded-xl bg-primary py-3 font-semibold text-primary-foreground",
						children: "اختيار الخطة"
					})
				]
			}, plan.id))
		})]
	});
}
//#endregion
export { MembershipPage as component };
