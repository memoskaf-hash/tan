import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/refunds-B0KG62h6.js
var import_jsx_runtime = require_jsx_runtime();
function Legal({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 leading-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-8 text-3xl font-bold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-5 text-muted-foreground",
			children
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
	title: "سياسة الاسترداد",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يمكن طلب الاسترداد خلال 14 يومًا من الشراء عبر صفحة المشتريات، ما لم ينص وصف المنتج على خلاف ذلك. تُراجع الطلبات يدويًا." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لا يتم تنفيذ الاسترداد قبل التحقق من حالة الدفع، وقد يستغرق ظهوره مدة مزود الدفع." })]
});
//#endregion
export { SplitComponent as component };
