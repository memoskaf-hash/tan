import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { c as Sparkles, i as Users, u as ShieldCheck, w as HeartHandshake } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BA-C-8A0.js
var import_jsx_runtime = require_jsx_runtime();
var VALUES = [
	{
		icon: Sparkles,
		title: "جودة قبل الكمية",
		text: "كل منتج يمرّ بمراجعة تحريرية وتقنية قبل نشره."
	},
	{
		icon: ShieldCheck,
		title: "دفع وتحميل آمن",
		text: "روابط تحميل خاصة لكل عملية شراء وحماية للملفات."
	},
	{
		icon: HeartHandshake,
		title: "دعم حقيقي",
		text: "فريق يجيب على أسئلتك خلال يوم عمل واحد."
	},
	{
		icon: Users,
		title: "مجتمع متعلّمين",
		text: "أكثر من 10 آلاف متدرب يشاركون خبراتهم ونتائجهم."
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold",
				children: "من نحن"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-3xl text-muted-foreground",
				children: "بدأنا جود من فكرة بسيطة: المحتوى العربي العملي نادر، ومن يجده غالبًا يدفع كثيرًا مقابل قليل. نبني اليوم مكتبة من القوالب والكتب والدورات التي تُختصر بها شهور من التجربة والخطأ، بلغة واضحة وأمثلة من السوق العربي."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 sm:grid-cols-2",
				children: VALUES.map(({ icon: Icon, title, text }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-lg font-bold",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: text
						})
					]
				}, title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-6 rounded-2xl border border-border bg-card p-8 sm:grid-cols-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-bold text-primary",
						children: "10,600+"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "متدرّب ومشترٍ"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-bold text-primary",
						children: "24"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "منتجًا وكورسًا"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-bold text-primary",
						children: "4.8/5"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "متوسط تقييم العملاء"
					})] })
				]
			})
		]
	});
}
//#endregion
export { AboutPage as component };
