import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { _ as Menu, a as UserRound, g as MessageCircle, l as ShoppingCart, n as X, p as PackageOpen, u as ShieldCheck, y as LogOut } from "../_libs/lucide-react.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
import { _ as useNavigate, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$26 } from "./auth-DtErqdQ0.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { i as useCart, t as CartProvider } from "./cart-_EkYk7BO.mjs";
import { n as LANGUAGES, r as useI18n, t as I18nProvider } from "./i18n-CdtaxMCT.mjs";
import { t as Route$27 } from "./product._slug-CnHoxJV5.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { i as stringType, n as numberType, r as objectType, t as enumType } from "../_libs/zod.mjs";
import processModule from "node:process";
import { Buffer } from "node:buffer";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Cjja-Rex.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Bco6VUQM.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var NAV = [
	{
		to: "/",
		label: "الرئيسية"
	},
	{
		to: "/courses",
		label: "الكورسات"
	},
	{
		to: "/membership",
		label: "العضويات"
	},
	{
		to: "/content",
		label: "المحتوى"
	},
	{
		to: "/about",
		label: "من نحن"
	},
	{
		to: "/contact",
		label: "تواصل معنا"
	}
];
function SiteHeader() {
	const { count } = useCart();
	const { user, signOut } = useAuth();
	const navigate = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	const { language, setLanguage, t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 border-b border-border bg-card/85 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-lg font-bold",
					children: language === "ar" ? "جود" : "Joud"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 md:flex",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						activeOptions: { exact: item.to === "/" },
						activeProps: { className: "bg-muted text-foreground" },
						className: "rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition hover:text-foreground",
						children: t(item.to === "/" ? "home" : item.to.slice(1))
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden items-center gap-2 text-sm text-muted-foreground lg:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-primary" }), t("secure")]
						}),
						user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/profile",
								className: "inline-flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-sm font-medium transition hover:bg-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: t("profile")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/purchases",
								className: "inline-flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-sm font-medium transition hover:bg-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageOpen, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: t("purchases")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: async () => {
									await signOut();
									navigate({ to: "/" });
								},
								title: t("logout"),
								className: "inline-flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-sm font-medium transition hover:bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" })
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/auth",
							search: { redirect: "/" },
							className: "inline-flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-sm font-medium transition hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: t("login")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/cart",
							className: "relative inline-flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-sm font-medium transition hover:bg-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "h-4 w-4" }),
								t("cart"),
								count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute -top-2 -left-2 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-xs font-bold text-primary-foreground",
									children: count
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setOpen((v) => !v),
							"aria-label": "القائمة",
							className: "rounded-xl border border-border p-2 md:hidden",
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: language,
							onChange: (e) => setLanguage(e.target.value),
							className: "rounded-lg border bg-background px-2 py-2 text-xs",
							"aria-label": "Language",
							children: Object.entries(LANGUAGES).map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: key,
								children: label
							}, key))
						})
					]
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "border-t border-border bg-card px-4 py-2 md:hidden",
			children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				onClick: () => setOpen(false),
				className: "block rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground",
				children: item.label
			}, item.to))
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-card/50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold",
					children: "جود"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "منتجات رقمية وكورسات تدريبية بالعربية، بتحميل فوري ودفع آمن."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "روابط سريعة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "hover:text-foreground",
							children: "الرئيسية"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/courses",
							className: "hover:text-foreground",
							children: "الكورسات"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "hover:text-foreground",
							children: "من نحن"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "hover:text-foreground",
							children: "تواصل معنا"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy",
							className: "hover:text-foreground",
							children: "الخصوصية"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/terms",
							className: "hover:text-foreground",
							children: "الشروط"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/refunds",
							className: "hover:text-foreground",
							children: "الاسترداد"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/cookies",
							className: "hover:text-foreground",
							children: "ملفات الارتباط"
						}) })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "الدعم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ضمان استرداد خلال 14 يومًا" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "دعم فني عبر البريد الإلكتروني" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "تحديثات مجانية للمنتجات" })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border py-6 text-center text-sm text-muted-foreground",
			children: [
				"جميع الحقوق محفوظة © ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" جود"
			]
		})]
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function ChatWidget() {
	const { t } = useI18n();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [input, setInput] = (0, import_react.useState)("");
	const [messages, setMessages] = (0, import_react.useState)([]);
	async function send() {
		if (!input.trim()) return;
		const text = input;
		setInput("");
		setMessages((m) => [...m, {
			role: "user",
			content: text
		}]);
		try {
			const d = await (await fetch("/api/chat", {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({ message: text })
			})).json();
			setMessages((m) => [...m, {
				role: "assistant",
				content: d.reply || d.error || "Chat is not configured."
			}]);
		} catch {
			setMessages((m) => [...m, {
				role: "assistant",
				content: "Chat is not configured. Please contact support."
			}]);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed bottom-5 left-5 z-30",
		children: [open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex h-96 w-80 flex-col rounded-2xl border bg-card p-3 shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("chat") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 space-y-2 overflow-auto py-3 text-sm",
					children: messages.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: m.role === "user" ? "text-primary" : "text-muted-foreground",
						children: m.content
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: input,
						onChange: (e) => setInput(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && send(),
						className: "min-w-0 flex-1 rounded-lg border px-2 py-2"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: send,
						className: "rounded-lg bg-primary px-3 text-primary-foreground",
						children: t("send")
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => setOpen(!open),
			className: "rounded-full bg-primary p-4 text-primary-foreground shadow-lg",
			"aria-label": t("chat"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {})
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$25 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "جود | منتجات رقمية وكورسات تدريبية" },
			{
				name: "description",
				content: "متجر عربي للمنتجات الرقمية والكورسات التدريبية مع تحميل فوري ووصول مدى الحياة."
			},
			{
				name: "author",
				content: "Lovable"
			},
			{
				property: "og:title",
				content: "جود | منتجات رقمية وكورسات تدريبية"
			},
			{
				property: "og:description",
				content: "متجر عربي للمنتجات الرقمية والكورسات التدريبية مع تحميل فوري ووصول مدى الحياة."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Noto+Kufi+Arabic:wght@600;700;800&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$25.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			dir: "rtl",
			className: "flex min-h-screen flex-col bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatWidget, {})
			]
		}) }) })
	});
}
var $$splitComponentImporter$16 = () => import("./routes-BRt4y6a3.mjs");
var Route$24 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "جود | منتجات رقمية وكورسات تدريبية" },
		{
			name: "description",
			content: "تصفح منتجاتنا الرقمية وكورساتنا التدريبية بالعربية: قوالب، كتب إلكترونية، ودورات احترافية بأسعار منافسة وتحميل فوري."
		},
		{
			property: "og:title",
			content: "جود | منتجات رقمية وكورسات تدريبية"
		},
		{
			property: "og:description",
			content: "قوالب، كتب إلكترونية، ودورات احترافية بالعربية — تحميل فوري ودفع آمن."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./about-BA-C-8A0.mjs");
var Route$23 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "من نحن | جود" },
		{
			name: "description",
			content: "تعرّف على فريق جود ورسالتنا في تقديم منتجات رقمية وكورسات تدريبية عربية عالية الجودة."
		},
		{
			property: "og:title",
			content: "من نحن | جود"
		},
		{
			property: "og:description",
			content: "رسالتنا: محتوى رقمي عربي عملي يوفّر وقتك ويطوّر مهاراتك."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./admin-COR12J9L.mjs");
var Route$22 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./affiliate-Bd1BsTcU.mjs");
var Route$21 = createFileRoute("/affiliate")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./cart-CzCN70dh.mjs");
var Route$20 = createFileRoute("/cart")({
	head: () => ({ meta: [
		{ title: "سلة المشتريات | جود" },
		{
			name: "description",
			content: "راجع منتجاتك الرقمية والكورسات قبل إتمام عملية الشراء."
		},
		{
			property: "og:title",
			content: "سلة المشتريات | جود"
		},
		{
			property: "og:description",
			content: "راجع مشترياتك الرقمية قبل الدفع."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./checkout-DtxyydTR.mjs");
var Route$19 = createFileRoute("/checkout")({
	head: () => ({ meta: [
		{ title: "إتمام الشراء | جود" },
		{
			name: "description",
			content: "أكمل بياناتك واحصل على روابط التحميل فور إتمام الدفع."
		},
		{
			property: "og:title",
			content: "إتمام الشراء | جود"
		},
		{
			property: "og:description",
			content: "دفع آمن وتحميل فوري للمنتجات الرقمية."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./contact-Dksd6_FW.mjs");
var Route$18 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "تواصل معنا | جود" },
		{
			name: "description",
			content: "أرسل استفسارك عن المنتجات الرقمية أو الكورسات وسنرد خلال يوم عمل واحد."
		},
		{
			property: "og:title",
			content: "تواصل معنا | جود"
		},
		{
			property: "og:description",
			content: "فريق الدعم يجيب على استفساراتك خلال يوم عمل واحد."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./content-CJJ4hQYH.mjs");
var Route$17 = createFileRoute("/content")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./cookies-B6U7Eo5C.mjs");
var Route$16 = createFileRoute("/cookies")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./courses-DIrGYoIN.mjs");
var Route$15 = createFileRoute("/courses")({
	head: () => ({ meta: [
		{ title: "الكورسات التدريبية | جود" },
		{
			name: "description",
			content: "كورسات تدريبية بالعربية في التسويق الرقمي، التصميم، والبرمجة مع شهادات إتمام ووصول مدى الحياة."
		},
		{
			property: "og:title",
			content: "الكورسات التدريبية | جود"
		},
		{
			property: "og:description",
			content: "دورات احترافية بالعربية مع وصول مدى الحياة وشهادة إتمام."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./learning-Bt_V1QJ4.mjs");
var Route$14 = createFileRoute("/learning")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./membership-Cf9ewM1g.mjs");
var Route$13 = createFileRoute("/membership")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./privacy-DBArstGe.mjs");
var Route$12 = createFileRoute("/privacy")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./profile-C_mCwwau.mjs");
var Route$11 = createFileRoute("/profile")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./purchases-6tru-MHQ.mjs");
var Route$10 = createFileRoute("/purchases")({
	head: () => ({ meta: [
		{ title: "مشترياتي | جود" },
		{
			name: "description",
			content: "كل طلباتك ومنتجاتك الرقمية في مكان واحد."
		},
		{
			property: "og:title",
			content: "مشترياتي | جود"
		},
		{
			property: "og:description",
			content: "كل طلباتك ومنتجاتك الرقمية في مكان واحد."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./refunds-B0KG62h6.mjs");
var Route$9 = createFileRoute("/refunds")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./terms-Dl2ZbTWE.mjs");
var Route$8 = createFileRoute("/terms")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
function createSupabaseAdminClient() {
	const SUPABASE_URL = processModule.env["SUPABASE_URL"];
	const SUPABASE_SERVICE_ROLE_KEY = processModule.env["SUPABASE_SERVICE_ROLE_KEY"];
	if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
		const message = `Missing Supabase environment variable(s): ${[...!SUPABASE_URL ? ["SUPABASE_URL"] : [], ...!SUPABASE_SERVICE_ROLE_KEY ? ["SUPABASE_SERVICE_ROLE_KEY"] : []].join(", ")}. Connect Supabase in Lovable Cloud.`;
		console.error(`[Supabase] ${message}`);
		throw new Error(message);
	}
	return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_SERVICE_ROLE_KEY) },
		auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		}
	});
}
var _supabaseAdmin;
var supabaseAdmin = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabaseAdmin) _supabaseAdmin = createSupabaseAdminClient();
	return Reflect.get(_supabaseAdmin, prop, receiver);
} });
var inputSchema = objectType({
	code: stringType().min(3).max(80),
	path: stringType().max(500).optional()
});
var digest = (value) => createHash("sha256").update(value).digest("hex");
var Route$7 = createFileRoute("/api/affiliate-click")({ server: { handlers: { POST: async ({ request }) => {
	const parsed = inputSchema.safeParse(await request.json().catch(() => null));
	if (!parsed.success) return Response.json({ error: "Invalid referral." }, { status: 400 });
	const referral = await supabaseAdmin.from("referrals").select("id,affiliate_id,vendor_id").eq("code", parsed.data.code).eq("status", "active").maybeSingle();
	if (referral.error || !referral.data) return Response.json({ error: "Referral not found." }, { status: 404 });
	const userAgent = request.headers.get("user-agent") ?? "unknown";
	const forwarded = request.headers.get("x-forwarded-for") ?? "unknown";
	const visitorHash = digest(`${forwarded}|${userAgent}`);
	if (!(await supabaseAdmin.from("referral_clicks").select("id").eq("referral_id", referral.data.id).eq("visitor_hash", visitorHash).gte("created_at", (/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString()).limit(1)).data?.length) await supabaseAdmin.from("referral_clicks").insert({
		referral_id: referral.data.id,
		visitor_hash: visitorHash,
		ip_hash: digest(forwarded),
		user_agent_hash: digest(userAgent),
		landing_path: parsed.data.path ?? "/"
	});
	return Response.json({ ok: true });
} } } });
var schema$2 = objectType({
	orderId: stringType().uuid(),
	referralCode: stringType().min(3),
	idempotencyKey: stringType().min(8).max(120),
	currency: stringType().length(3).default("USD")
});
function serverExchangeRate(currency) {
	if (currency === "USD") return 1;
	try {
		const rate = JSON.parse(processModule.env.AFFILIATE_FX_RATES_JSON ?? "{}")[currency];
		return typeof rate === "number" && Number.isFinite(rate) && rate > 0 ? rate : null;
	} catch (error) {
		console.error("[affiliate] invalid AFFILIATE_FX_RATES_JSON", error);
		return null;
	}
}
var Route$6 = createFileRoute("/api/affiliate-conversion")({ server: { handlers: { POST: async ({ request }) => {
	const parsed = schema$2.safeParse(await request.json().catch(() => null));
	if (!parsed.success) return Response.json({ error: "Invalid conversion." }, { status: 400 });
	const input = parsed.data;
	const exchangeRate = serverExchangeRate(input.currency);
	if (exchangeRate === null) return Response.json({ error: "Currency conversion is not configured for this currency." }, { status: 503 });
	const existing = await supabaseAdmin.from("affiliate_sales").select("*").eq("idempotency_key", input.idempotencyKey).maybeSingle();
	if (existing.data) return Response.json({
		sale: existing.data,
		idempotent: true
	});
	const [{ data: referral }, { data: order }] = await Promise.all([supabaseAdmin.from("referrals").select("id,affiliate_id,vendor_id").eq("code", input.referralCode).eq("status", "active").maybeSingle(), supabaseAdmin.from("orders").select("id,user_id,total,status,country").eq("id", input.orderId).maybeSingle()]);
	if (!referral?.vendor_id || !order || !["paid", "confirmed"].includes(order.status)) return Response.json({ error: "Conversion cannot be attributed." }, { status: 409 });
	if (referral.affiliate_id === order.user_id) {
		await supabaseAdmin.from("fraud_flags").insert({
			vendor_id: referral.vendor_id,
			referral_id: referral.id,
			reason: "self_referral",
			severity: "high"
		});
		return Response.json({ error: "Self-referrals are not eligible." }, { status: 422 });
	}
	const { data: tier } = await supabaseAdmin.rpc("evaluate_affiliate_tier", { p_gross: order.total }).maybeSingle();
	const platformCut = Number(tier?.platform_cut_percent ?? 15);
	const gross = Number(order.total);
	const platformFee = Math.round(gross * platformCut) / 100;
	const commission = Math.round((gross - platformFee) * exchangeRate * 100) / 100;
	const { data: sale, error } = await supabaseAdmin.from("affiliate_sales").insert({
		referral_id: referral.id,
		vendor_id: referral.vendor_id,
		order_id: order.id,
		customer_id: order.user_id,
		currency: input.currency,
		gross_amount: gross,
		platform_fee_amount: platformFee,
		commission_amount: commission,
		exchange_rate: exchangeRate,
		tier_id: tier?.tier_id ?? null,
		idempotency_key: input.idempotencyKey,
		status: "pending"
	}).select().single();
	if (error) return Response.json({ error: "Conversion already recorded or unavailable." }, { status: 409 });
	await supabaseAdmin.from("commission_ledger").insert({
		vendor_id: referral.vendor_id,
		affiliate_sale_id: sale.id,
		entry_type: "credit",
		amount: commission,
		currency: input.currency,
		description: "Affiliate sale pending approval",
		idempotency_key: `sale:${sale.id}`
	});
	return Response.json({ sale });
} } } });
var Route$5 = createFileRoute("/api/affiliate-referral")({ server: { handlers: { POST: async ({ request }) => {
	const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
	if (!token) return Response.json({ error: "Unauthorized" }, { status: 401 });
	const { data: auth } = await supabaseAdmin.auth.getUser(token);
	if (!auth.user) return Response.json({ error: "Unauthorized" }, { status: 401 });
	await supabaseAdmin.from("vendors").upsert({
		user_id: auth.user.id,
		business_name: "Partner",
		status: "pending"
	}, {
		onConflict: "user_id",
		ignoreDuplicates: true
	});
	const vendor = await supabaseAdmin.from("vendors").select("id").eq("user_id", auth.user.id).maybeSingle();
	if (!vendor.data) return Response.json({ error: "Vendor setup unavailable." }, { status: 503 });
	const existing = await supabaseAdmin.from("referrals").select("*").eq("affiliate_id", auth.user.id).eq("status", "active").maybeSingle();
	if (existing.data) return Response.json({ referral: existing.data });
	const code = `REF-${auth.user.id.slice(0, 8).toUpperCase()}`;
	const { data, error } = await supabaseAdmin.from("referrals").insert({
		affiliate_id: auth.user.id,
		vendor_id: vendor.data.id,
		code,
		coupon_code: code
	}).select().single();
	return error ? Response.json({ error: "Referral unavailable." }, { status: 409 }) : Response.json({ referral: data }, { status: 201 });
} } } });
var requests = /* @__PURE__ */ new Map();
var Route$4 = createFileRoute("/api/chat")({ server: { handlers: { POST: async ({ request }) => {
	const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
	const now = Date.now();
	const entry = requests.get(ip);
	if (entry && entry.reset > now && entry.count >= 10) return Response.json({ error: "Too many messages. Please try again later." }, { status: 429 });
	if (!entry || entry.reset <= now) requests.set(ip, {
		count: 1,
		reset: now + 6e4
	});
	else entry.count++;
	const key = processModule.env.OPENAI_API_KEY;
	if (!key) return Response.json({ error: "Chat is not configured: OPENAI_API_KEY is missing." }, { status: 503 });
	const parsed = objectType({ message: stringType().trim().min(1).max(2e3) }).safeParse(await request.json().catch(() => null));
	if (!parsed.success) return Response.json({ error: "Message must be between 1 and 2000 characters." }, { status: 400 });
	const { message } = parsed.data;
	const response = await fetch("https://api.openai.com/v1/chat/completions", {
		method: "POST",
		headers: {
			"content-type": "application/json",
			Authorization: `Bearer ${key}`
		},
		body: JSON.stringify({
			model: "gpt-4o-mini",
			messages: [{
				role: "system",
				content: "You are a concise helpful store assistant."
			}, {
				role: "user",
				content: message
			}]
		})
	});
	const data = await response.json();
	return Response.json({ reply: data.choices?.[0]?.message?.content ?? "Unable to answer." }, { status: response.status });
} } } });
var Route$3 = createFileRoute("/api/download")({ server: { handlers: { POST: async ({ request }) => {
	const parsed = objectType({ fileId: stringType().uuid() }).safeParse(await request.json().catch(() => null));
	const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
	if (!parsed.success || !token) return Response.json({ error: "Authentication and fileId are required." }, { status: 400 });
	const { data: userData } = await supabaseAdmin.auth.getUser(token);
	if (!userData.user) return Response.json({ error: "Unauthorized." }, { status: 401 });
	const { data: file } = await supabaseAdmin.from("digital_files").select("storage_path, product_id").eq("id", parsed.data.fileId).single();
	if (!file) return Response.json({ error: "File not found." }, { status: 404 });
	const { data: purchase } = await supabaseAdmin.from("order_items").select("order_id, orders!inner(user_id,status)").eq("product_id", file.product_id).eq("orders.user_id", userData.user.id).in("orders.status", ["confirmed", "paid"]).limit(1).maybeSingle();
	const isAdmin = ["admin", "super_admin"].includes(String(userData.user.app_metadata?.role ?? ""));
	if (!purchase && !isAdmin) return Response.json({ error: "Purchase required." }, { status: 403 });
	const { data, error } = await supabaseAdmin.storage.from("digital-files").createSignedUrl(file.storage_path, 300);
	if (error) return Response.json({ error: "Unable to create download link." }, { status: 500 });
	return Response.json({
		url: data.signedUrl,
		expiresIn: 300
	});
} } } });
function verify(raw, signature, secret) {
	const timestamp = signature.match(/(?:^|,)t=(\d+)/)?.[1];
	const provided = signature.match(/(?:^|,)v1=([a-f0-9]+)/)?.[1];
	if (!timestamp || !provided || Math.abs(Date.now() / 1e3 - Number(timestamp)) > 300) return false;
	const expected = createHmac("sha256", secret).update(`${timestamp}.${raw}`).digest("hex");
	return expected.length === provided.length && timingSafeEqual(Buffer.from(expected), Buffer.from(provided));
}
var Route$2 = createFileRoute("/api/payment-webhooks")({ server: { handlers: { POST: async ({ request }) => {
	const provider = new URL(request.url).searchParams.get("provider");
	const raw = await request.text();
	let event;
	try {
		event = JSON.parse(raw);
	} catch {
		return Response.json({ error: "Invalid JSON." }, { status: 400 });
	}
	if (provider === "stripe") {
		const secret = processModule.env.STRIPE_WEBHOOK_SECRET;
		const signature = request.headers.get("stripe-signature");
		if (!secret || !signature) return Response.json({ error: "Stripe webhook verification is not configured." }, { status: 503 });
		if (!verify(raw, signature, secret)) return Response.json({ error: "Invalid Stripe signature." }, { status: 401 });
	} else if (provider === "paypal") return Response.json({ error: "PayPal verification requires PAYPAL_WEBHOOK_ID and provider verification API; fulfillment is disabled." }, { status: 501 });
	else if (provider === "moyasar") {
		const secret = processModule.env.MOYASAR_WEBHOOK_SECRET;
		if (!secret) return Response.json({ error: "Moyasar webhook verification is not configured." }, { status: 503 });
		const signature = request.headers.get("x-moyasar-signature");
		if (!signature || !verify(raw, `t=${Math.floor(Date.now() / 1e3)},v1=${signature}`, secret)) return Response.json({ error: "Invalid Moyasar signature." }, { status: 401 });
	} else return Response.json({ error: "provider must be stripe, paypal, or moyasar." }, { status: 400 });
	const data = event.data?.object ?? event;
	const reference = String(data.id ?? data.payment_id ?? data.order_id ?? "");
	const kind = String(event.type ?? data.status ?? "").toLowerCase();
	const paid = [
		"paid",
		"succeeded",
		"completed",
		"captured"
	].some((value) => kind.includes(value));
	if (reference) await supabaseAdmin.from("orders").update({
		status: paid ? "paid" : "payment_failed",
		provider_reference: reference
	}).eq("provider_reference", reference);
	const notificationUrl = processModule.env.EMAIL_AUTOMATION_WEBHOOK_URL;
	if (notificationUrl && (paid || kind.includes("refund") || kind.includes("abandon"))) await fetch(notificationUrl, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			event: paid ? "receipt" : kind.includes("refund") ? "refund" : "abandoned_cart",
			provider,
			reference
		})
	}).catch((error) => console.error("[notifications] webhook failed", error));
	else if (!notificationUrl) console.warn("[notifications] EMAIL_AUTOMATION_WEBHOOK_URL is not configured; no email was sent.");
	return Response.json({
		received: true,
		verified: true,
		status: paid ? "paid" : "ignored"
	});
} } } });
var schema$1 = objectType({
	provider: enumType([
		"stripe",
		"paypal",
		"moyasar"
	]),
	amount: numberType().positive().max(1e5),
	currency: stringType().length(3).default("USD"),
	description: stringType().min(1).max(200),
	successUrl: stringType().url(),
	cancelUrl: stringType().url()
});
var configured = (provider) => provider === "stripe" ? Boolean(processModule.env.STRIPE_SECRET_KEY) : provider === "paypal" ? Boolean(processModule.env.PAYPAL_CLIENT_ID && processModule.env.PAYPAL_CLIENT_SECRET) : Boolean(processModule.env.MOYASAR_API_KEY);
var Route$1 = createFileRoute("/api/payments")({ server: { handlers: {
	GET: () => Response.json({ providers: {
		stripe: configured("stripe"),
		paypal: configured("paypal"),
		moyasar: configured("moyasar")
	} }),
	POST: async ({ request }) => {
		const bearer = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
		if (!bearer) return Response.json({ error: "Authentication is required to start a payment." }, { status: 401 });
		const { data: authData } = await supabaseAdmin.auth.getUser(bearer);
		if (!authData.user) return Response.json({ error: "Unauthorized." }, { status: 401 });
		const parsed = schema$1.safeParse(await request.json().catch(() => null));
		if (!parsed.success) return Response.json({ error: "Invalid payment request." }, { status: 400 });
		const input = parsed.data;
		if (!configured(input.provider)) return Response.json({ error: `${input.provider} is not configured on the server.` }, { status: 503 });
		try {
			if (input.provider === "stripe") {
				const body = new URLSearchParams({
					mode: "payment",
					success_url: input.successUrl,
					cancel_url: input.cancelUrl,
					"line_items[0][price_data][currency]": input.currency.toLowerCase(),
					"line_items[0][price_data][product_data][name]": input.description,
					"line_items[0][price_data][unit_amount]": String(Math.round(input.amount * 100)),
					"line_items[0][quantity]": "1"
				});
				const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
					method: "POST",
					headers: {
						Authorization: `Bearer ${processModule.env.STRIPE_SECRET_KEY}`,
						"content-type": "application/x-www-form-urlencoded"
					},
					body
				});
				const data = await response.json();
				if (!response.ok) throw new Error(data.error?.message ?? "Stripe request failed");
				return Response.json({
					redirectUrl: data.url,
					sessionId: data.id,
					status: "pending_verification"
				});
			}
			if (input.provider === "paypal") {
				const auth = Buffer.from(`${processModule.env.PAYPAL_CLIENT_ID}:${processModule.env.PAYPAL_CLIENT_SECRET}`).toString("base64");
				const base = processModule.env.PAYPAL_API_BASE ?? "https://api-m.sandbox.paypal.com";
				const tokenResponse = await fetch(`${base}/v1/oauth2/token`, {
					method: "POST",
					headers: {
						Authorization: `Basic ${auth}`,
						"content-type": "application/x-www-form-urlencoded"
					},
					body: "grant_type=client_credentials"
				});
				const token = await tokenResponse.json();
				if (!tokenResponse.ok) throw new Error("PayPal authentication failed");
				const response = await fetch(`${base}/v2/checkout/orders`, {
					method: "POST",
					headers: {
						Authorization: `Bearer ${token.access_token}`,
						"content-type": "application/json"
					},
					body: JSON.stringify({
						intent: "CAPTURE",
						purchase_units: [{
							amount: {
								currency_code: input.currency,
								value: input.amount.toFixed(2)
							},
							description: input.description
						}],
						application_context: {
							return_url: input.successUrl,
							cancel_url: input.cancelUrl
						}
					})
				});
				const data = await response.json();
				if (!response.ok) throw new Error("PayPal order creation failed");
				return Response.json({
					redirectUrl: data.links?.find((link) => link.rel === "approve")?.href,
					sessionId: data.id,
					status: "pending_verification"
				});
			}
			const response = await fetch("https://api.moyasar.com/v1/payments", {
				method: "POST",
				headers: {
					Authorization: `Basic ${Buffer.from(`${processModule.env.MOYASAR_API_KEY}:`).toString("base64")}`,
					"content-type": "application/json"
				},
				body: JSON.stringify({
					amount: Math.round(input.amount * 100),
					currency: input.currency,
					description: input.description,
					callback_url: input.successUrl
				})
			});
			const data = await response.json();
			if (!response.ok) throw new Error(data.message ?? "Moyasar request failed");
			return Response.json({
				redirectUrl: data.source?.transaction_url,
				sessionId: data.id,
				status: "pending_verification"
			});
		} catch (error) {
			return Response.json({ error: error instanceof Error ? error.message : "Payment provider error." }, { status: 502 });
		}
	}
} } });
var schema = objectType({
	vendorId: stringType().uuid(),
	amount: numberType().positive().max(1e5),
	currency: stringType().length(3).default("USD")
});
var Route = createFileRoute("/api/payouts")({ server: { handlers: {
	GET: async ({ request }) => {
		const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
		if (!token) return Response.json({ error: "Unauthorized" }, { status: 401 });
		const { data } = await supabaseAdmin.auth.getUser(token);
		if (!data.user) return Response.json({ error: "Unauthorized" }, { status: 401 });
		const vendor = await supabaseAdmin.from("vendors").select("id").eq("user_id", data.user.id).maybeSingle();
		if (!vendor.data) return Response.json({ error: "Vendor account required" }, { status: 403 });
		const result = await supabaseAdmin.from("payouts").select("*").eq("vendor_id", vendor.data.id).order("requested_at", { ascending: false });
		return Response.json({ payouts: result.data ?? [] });
	},
	POST: async ({ request }) => {
		const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
		if (!token) return Response.json({ error: "Unauthorized" }, { status: 401 });
		const { data: auth } = await supabaseAdmin.auth.getUser(token);
		const parsed = schema.safeParse(await request.json().catch(() => null));
		if (!auth.user || !parsed.success) return Response.json({ error: "Invalid request" }, { status: 400 });
		const vendor = await supabaseAdmin.from("vendors").select("id").eq("id", parsed.data.vendorId).eq("user_id", auth.user.id).maybeSingle();
		if (!vendor.data) return Response.json({ error: "Forbidden" }, { status: 403 });
		const [credits, debits, payouts] = await Promise.all([
			supabaseAdmin.from("commission_ledger").select("amount").eq("vendor_id", vendor.data.id).eq("currency", parsed.data.currency).in("entry_type", ["credit", "adjustment"]).in("status", ["available", "pending"]),
			supabaseAdmin.from("commission_ledger").select("amount").eq("vendor_id", vendor.data.id).eq("currency", parsed.data.currency).in("entry_type", [
				"debit",
				"clawback",
				"payout"
			]),
			supabaseAdmin.from("payouts").select("amount").eq("vendor_id", vendor.data.id).eq("currency", parsed.data.currency).in("status", [
				"requested",
				"processing",
				"paid"
			])
		]);
		const sum = (rows) => (rows ?? []).reduce((total, row) => total + Number(row.amount), 0);
		const available = sum(credits.data) - sum(debits.data) - sum(payouts.data);
		if (parsed.data.amount > available) return Response.json({ error: "Payout exceeds available commission balance." }, { status: 422 });
		const { data, error } = await supabaseAdmin.from("payouts").insert({
			...parsed.data,
			vendor_id: vendor.data.id
		}).select().single();
		return error ? Response.json({ error: "Payout unavailable" }, { status: 409 }) : Response.json({ payout: data }, { status: 201 });
	}
} } });
var rootRouteChildren = {
	IndexRoute: Route$24.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$25
	}),
	AboutRoute: Route$23.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$25
	}),
	AdminRoute: Route$22.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$25
	}),
	AffiliateRoute: Route$21.update({
		id: "/affiliate",
		path: "/affiliate",
		getParentRoute: () => Route$25
	}),
	AuthRoute: Route$26.update({
		id: "/auth",
		path: "/auth",
		getParentRoute: () => Route$25
	}),
	CartRoute: Route$20.update({
		id: "/cart",
		path: "/cart",
		getParentRoute: () => Route$25
	}),
	CheckoutRoute: Route$19.update({
		id: "/checkout",
		path: "/checkout",
		getParentRoute: () => Route$25
	}),
	ContactRoute: Route$18.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$25
	}),
	ContentRoute: Route$17.update({
		id: "/content",
		path: "/content",
		getParentRoute: () => Route$25
	}),
	CookiesRoute: Route$16.update({
		id: "/cookies",
		path: "/cookies",
		getParentRoute: () => Route$25
	}),
	CoursesRoute: Route$15.update({
		id: "/courses",
		path: "/courses",
		getParentRoute: () => Route$25
	}),
	LearningRoute: Route$14.update({
		id: "/learning",
		path: "/learning",
		getParentRoute: () => Route$25
	}),
	MembershipRoute: Route$13.update({
		id: "/membership",
		path: "/membership",
		getParentRoute: () => Route$25
	}),
	PrivacyRoute: Route$12.update({
		id: "/privacy",
		path: "/privacy",
		getParentRoute: () => Route$25
	}),
	ProfileRoute: Route$11.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => Route$25
	}),
	PurchasesRoute: Route$10.update({
		id: "/purchases",
		path: "/purchases",
		getParentRoute: () => Route$25
	}),
	RefundsRoute: Route$9.update({
		id: "/refunds",
		path: "/refunds",
		getParentRoute: () => Route$25
	}),
	TermsRoute: Route$8.update({
		id: "/terms",
		path: "/terms",
		getParentRoute: () => Route$25
	}),
	ApiAffiliateClickRoute: Route$7.update({
		id: "/api/affiliate-click",
		path: "/api/affiliate-click",
		getParentRoute: () => Route$25
	}),
	ApiAffiliateConversionRoute: Route$6.update({
		id: "/api/affiliate-conversion",
		path: "/api/affiliate-conversion",
		getParentRoute: () => Route$25
	}),
	ApiAffiliateReferralRoute: Route$5.update({
		id: "/api/affiliate-referral",
		path: "/api/affiliate-referral",
		getParentRoute: () => Route$25
	}),
	ApiChatRoute: Route$4.update({
		id: "/api/chat",
		path: "/api/chat",
		getParentRoute: () => Route$25
	}),
	ApiDownloadRoute: Route$3.update({
		id: "/api/download",
		path: "/api/download",
		getParentRoute: () => Route$25
	}),
	ApiPaymentWebhooksRoute: Route$2.update({
		id: "/api/payment-webhooks",
		path: "/api/payment-webhooks",
		getParentRoute: () => Route$25
	}),
	ApiPaymentsRoute: Route$1.update({
		id: "/api/payments",
		path: "/api/payments",
		getParentRoute: () => Route$25
	}),
	ApiPayoutsRoute: Route.update({
		id: "/api/payouts",
		path: "/api/payouts",
		getParentRoute: () => Route$25
	}),
	ProductSlugRoute: Route$27.update({
		id: "/product/$slug",
		path: "/product/$slug",
		getParentRoute: () => Route$25
	})
};
var routeTree = Route$25._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
