import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-7BLMVn74.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useAuth() {
	const [session, setSession] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => {
			setSession(data.session);
			setLoading(false);
		});
		const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, s) => {
			setSession(s);
			setLoading(false);
		});
		return () => subscription.unsubscribe();
	}, []);
	return {
		session,
		user: session?.user ?? null,
		loading,
		signOut: () => supabase.auth.signOut()
	};
}
//#endregion
export { useAuth as t };
