import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Clock, P as CircleCheck, T as GraduationCap, i as Users, k as Download, s as Star, u as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useCart, n as PRODUCTS } from "./cart-_EkYk7BO.mjs";
import { t as ProductCard } from "./ProductCard-JSw-7AHV.mjs";
import { t as Route } from "./product._slug-CnHoxJV5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._slug-5jbXYb39.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { product } = Route.useLoaderData();
	const { add, has } = useCart();
	const { user } = useAuth();
	const [favorite, setFavorite] = (0, import_react.useState)(false);
	const [reviews, setReviews] = (0, import_react.useState)([]);
	const [review, setReview] = (0, import_react.useState)("");
	const [reviewRating, setReviewRating] = (0, import_react.useState)(5);
	const inCart = has(product.id);
	const related = PRODUCTS.filter((p) => p.type === product.type && p.id !== product.id).slice(0, 3);
	(0, import_react.useEffect)(() => {
		supabase.from("product_reviews").select("id,rating,body").eq("product_id", product.id).eq("approved", true).then(({ data }) => setReviews(data ?? []));
		if (user) supabase.from("favorites").select("product_id").eq("user_id", user.id).eq("product_id", product.id).maybeSingle().then(({ data }) => setFavorite(Boolean(data)));
	}, [product.id, user]);
	async function toggleFavorite() {
		if (!user) return;
		if (favorite) await supabase.from("favorites").delete().eq("user_id", user.id).eq("product_id", product.id);
		else await supabase.from("favorites").insert({
			user_id: user.id,
			product_id: product.id
		});
		setFavorite(!favorite);
	}
	async function submitReview() {
		if (!user || review.trim().length < 3) return;
		const { data } = await supabase.from("product_reviews").insert({
			product_id: product.id,
			user_id: user.id,
			rating: reviewRating,
			body: review.trim()
		}).select("id,rating,body").single();
		if (data) setReviews([...reviews, data]);
		setReview("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${product.type === "digital" ? "bg-secondary text-secondary-foreground" : "bg-primary/10 text-primary"}`,
						children: [product.type === "digital" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-3.5 w-3.5" }), product.type === "digital" ? "منتج رقمي" : "كورس تدريبي"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 text-3xl font-bold leading-snug",
						children: product.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center gap-5 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-accent text-accent" }), product.rating.toFixed(1)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4" }),
									product.students.toLocaleString("ar-EG"),
									" متدرب"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" }), product.meta]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 leading-relaxed text-muted-foreground",
						children: product.longDescription
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-10 text-xl font-bold",
						children: "ماذا ستحصل عليه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: product.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-4 w-4 shrink-0 text-primary" }), f]
						}, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-10 text-xl font-bold",
						children: product.type === "course" ? "محتوى الكورس" : "محتويات الحزمة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card",
						children: product.curriculum.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 px-5 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-6 w-6 items-center justify-center rounded-full bg-muted text-xs",
									children: i + 1
								}), c.title]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: c.duration
							})]
						}, c.title))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "h-fit lg:sticky lg:top-24 lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-4xl font-bold",
								children: ["$", product.price]
							}), product.oldPrice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "pb-1 text-lg text-muted-foreground line-through",
								children: ["$", product.oldPrice]
							})]
						}),
						product.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-3 inline-block rounded-md bg-accent/20 px-2 py-0.5 text-xs font-semibold text-accent-foreground",
							children: product.badge
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => add(product.id),
							disabled: inCart,
							className: "mt-6 w-full rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60",
							children: inCart ? "أُضيف إلى السلة" : "أضف إلى السلة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: toggleFavorite,
							disabled: !user,
							className: "mt-3 w-full rounded-xl border border-border py-3 text-sm font-medium hover:bg-muted disabled:opacity-50",
							children: favorite ? "♥ محفوظ في المفضلة" : "♡ أضف إلى المفضلة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/cart",
							className: "mt-3 block rounded-xl border border-border py-3 text-center text-sm font-medium transition hover:bg-muted",
							children: "الذهاب إلى السلة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-6 space-y-3 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-primary" }), " دفع آمن وضمان استرداد 14 يومًا"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4 text-primary" }), " وصول فوري بعد الشراء"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-primary" }),
										" المدرّب: ",
										product.instructor
									]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16 rounded-2xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold",
							children: "التقييمات والمراجعات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 space-y-3",
							children: reviews.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "لا توجد مراجعات منشورة بعد."
							}) : reviews.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-xl bg-muted/50 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-accent",
									children: ["★".repeat(item.rating), "☆".repeat(5 - item.rating)]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: item.body
								})]
							}, item.id))
						}),
						user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-3 sm:grid-cols-[auto_1fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: reviewRating,
									onChange: (e) => setReviewRating(Number(e.target.value)),
									className: "rounded-lg border bg-background p-2",
									children: [
										5,
										4,
										3,
										2,
										1
									].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: n,
										children: [n, " نجوم"]
									}, n))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: review,
									onChange: (e) => setReview(e.target.value),
									maxLength: 2e3,
									placeholder: "اكتب مراجعتك (ستُنشر بعد المراجعة)",
									className: "rounded-lg border bg-background px-3"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: submitReview,
									className: "rounded-lg bg-primary px-4 py-2 text-primary-foreground",
									children: "إرسال"
								})
							]
						})
					]
				})]
			})]
		}), related.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: "قد يعجبك أيضًا"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { item }, item.id))
			})]
		})]
	});
}
//#endregion
export { ProductPage as component };
