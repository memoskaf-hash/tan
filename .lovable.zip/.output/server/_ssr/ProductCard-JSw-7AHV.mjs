import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { P as CircleCheck, T as GraduationCap, k as Download, s as Star } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useCart } from "./cart-_EkYk7BO.mjs";
import { r as useI18n } from "./i18n-CdtaxMCT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ProductCard-JSw-7AHV.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ item }) {
	const { add, has } = useCart();
	const inCart = has(item.id);
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col justify-between rounded-2xl border border-border bg-card p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			item.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: item.image_url,
				alt: item.title,
				loading: "lazy",
				className: "mb-5 h-40 w-full rounded-xl object-cover transition duration-300 hover:scale-[1.02]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${item.type === "digital" ? "bg-secondary text-secondary-foreground" : "bg-primary/10 text-primary"}`,
					children: [item.type === "digital" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-3.5 w-3.5" }), item.type === "digital" ? t("digital") : t("course")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-2xl font-bold",
						children: ["$", item.price]
					}), item.oldPrice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mr-2 text-sm text-muted-foreground line-through",
						children: ["$", item.oldPrice]
					})]
				})]
			}),
			item.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-2 inline-block rounded-md bg-accent/20 px-2 py-0.5 text-xs font-semibold text-accent-foreground",
				children: item.badge
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-lg font-bold",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/product/$slug",
					params: { slug: item.slug },
					className: "hover:text-primary",
					children: item.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center gap-2 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-accent text-accent" }),
					item.rating.toFixed(1),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"· ",
						item.students.toLocaleString("ar-EG"),
						" متدرب"
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted-foreground",
				children: item.description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-4 space-y-2",
				children: item.features.slice(0, 3).map((feat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0 text-primary" }), feat]
				}, feat))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-6 text-xs text-muted-foreground",
				children: item.meta
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => add(item.id),
				disabled: inCart,
				className: "flex-1 rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60",
				children: inCart ? t("inCart") : t("add")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/product/$slug",
				params: { slug: item.slug },
				className: "rounded-xl border border-border px-4 py-3 text-sm font-medium transition hover:bg-muted",
				children: t("details")
			})]
		})]
	});
}
//#endregion
export { ProductCard as t };
