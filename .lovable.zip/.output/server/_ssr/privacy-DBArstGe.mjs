import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-DBArstGe.js
var import_jsx_runtime = require_jsx_runtime();
function Legal({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 leading-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-8 text-3xl font-bold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-5 text-muted-foreground",
			children
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
	title: "سياسة الخصوصية",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "نستخدم بيانات الحساب والطلبات لتقديم المنتجات الرقمية ودعم العملاء. لا نبيع بياناتك، ونحتفظ بها وفق المتطلبات القانونية." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يمكنك طلب الوصول أو التصحيح أو الحذف عبر صفحة التواصل، مع مراعاة سجلات المعاملات المطلوبة قانونيًا." })]
});
//#endregion
export { SplitComponent as component };
