import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cookies-B6U7Eo5C.js
var import_jsx_runtime = require_jsx_runtime();
function Legal({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 leading-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-8 text-3xl font-bold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-5 text-muted-foreground",
			children
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legal, {
	title: "سياسة ملفات الارتباط",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "نستخدم التخزين المحلي للسلة وتفضيلات اللغة، وملفات ضرورية لتسجيل الدخول. لا نستخدم ملفات إعلانية اختيارية دون موافقة." })
});
//#endregion
export { SplitComponent as component };
