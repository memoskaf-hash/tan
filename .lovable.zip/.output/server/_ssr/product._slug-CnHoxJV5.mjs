import { M as notFound, f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fetchProducts } from "./cart-_EkYk7BO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._slug-CnHoxJV5.js
var $$splitComponentImporter = () => import("./product._slug-5jbXYb39.mjs");
var $$splitNotFoundComponentImporter = () => import("./product._slug-DNsoIzAb.mjs");
var Route = createFileRoute("/product/$slug")({
	loader: async ({ params }) => {
		const product = (await fetchProducts()).find((p) => p.slug === params.slug);
		if (!product) throw notFound();
		return { product };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "المنتج غير متوفر | جود" }, {
			name: "robots",
			content: "noindex"
		}] };
		const { product } = loaderData;
		const title = `${product.title} | جود`;
		return { meta: [
			{ title },
			{
				name: "description",
				content: product.description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: product.description
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
