import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-C_mCwwau.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Profile() {
	const { user, loading } = useAuth();
	const [name, setName] = (0, import_react.useState)(user?.user_metadata?.full_name ?? "");
	const [phone, setPhone] = (0, import_react.useState)(user?.phone ?? "");
	const [avatar, setAvatar] = (0, import_react.useState)(user?.user_metadata?.avatar_url ?? "");
	const [password, setPassword] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (user) {
			setName(user.user_metadata?.full_name ?? "");
			setPhone(user.phone ?? "");
			setAvatar(user.user_metadata?.avatar_url ?? "");
		}
	}, [user]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-xl px-4 py-12",
		children: "جارٍ تحميل الملف الشخصي…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-xl px-4 py-12 text-center",
		children: "يرجى تسجيل الدخول للوصول إلى ملفك الشخصي."
	});
	async function save() {
		const { error } = await supabase.auth.updateUser({
			data: {
				full_name: name,
				avatar_url: avatar
			},
			phone: phone || void 0
		});
		if (error) toast.error(error.message);
		else {
			await supabase.from("profiles").upsert({
				id: user.id,
				full_name: name,
				phone,
				avatar_url: avatar
			});
			toast.success("تم تحديث الملف الشخصي");
		}
	}
	async function changePassword() {
		const { error } = await supabase.auth.updateUser({ password });
		if (error) toast.error(error.message);
		else {
			setPassword("");
			toast.success("تم تغيير كلمة المرور");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-6 text-2xl font-bold",
			children: "الملف الشخصي"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 rounded-2xl border bg-card p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["الاسم", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "mt-1 w-full rounded-lg border p-2"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["الهاتف", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						className: "mt-1 w-full rounded-lg border p-2",
						dir: "ltr"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["رابط الصورة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: avatar,
						onChange: (e) => setAvatar(e.target.value),
						className: "mt-1 w-full rounded-lg border p-2",
						dir: "ltr"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: save,
					className: "rounded-lg bg-primary px-4 py-2 text-primary-foreground",
					children: "حفظ البيانات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["كلمة المرور الجديدة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						value: password,
						onChange: (e) => setPassword(e.target.value),
						className: "mt-1 w-full rounded-lg border p-2",
						dir: "ltr"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: changePassword,
					disabled: !password,
					className: "rounded-lg border px-4 py-2 disabled:opacity-50",
					children: "تغيير كلمة المرور"
				})
			]
		})]
	});
}
//#endregion
export { Profile as component };
