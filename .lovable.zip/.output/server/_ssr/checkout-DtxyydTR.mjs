import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { P as CircleCheck, S as LoaderCircle, k as Download, u as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as supabase } from "./client-B27-xJdw.mjs";
import { t as useAuth } from "./auth-7BLMVn74.mjs";
import { _ as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as useCart } from "./cart-_EkYk7BO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-DtxyydTR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CheckoutPage() {
	const { items, total, clear } = useCart();
	const { user, loading } = useAuth();
	const navigate = useNavigate();
	const [done, setDone] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [country, setCountry] = (0, import_react.useState)("");
	const [provider, setProvider] = (0, import_react.useState)("manual");
	const [available, setAvailable] = (0, import_react.useState)({});
	const [invoice, setInvoice] = (0, import_react.useState)(null);
	const [orderId, setOrderId] = (0, import_react.useState)(null);
	const [refundReason, setRefundReason] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		fetch("/api/payments").then((response) => response.ok ? response.json() : null).then((data) => data && setAvailable(data.providers)).catch(() => setAvailable({}));
	}, []);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[50vh] items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" })
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mx-auto h-12 w-12 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 text-2xl font-bold",
				children: "سجّل دخولك لإتمام الشراء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted-foreground",
				children: "نحفظ مشترياتك في حسابك لتصل إليها في أي وقت ومن أي جهاز."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({
					to: "/auth",
					search: { redirect: "/checkout" }
				}),
				className: "mt-6 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground hover:opacity-90",
				children: "تسجيل الدخول / إنشاء حساب"
			})
		]
	});
	async function handleSubmit(e) {
		e.preventDefault();
		if (!user) return;
		setBusy(true);
		try {
			if (provider !== "manual") {
				const response = await fetch("/api/payments", {
					method: "POST",
					headers: {
						"content-type": "application/json",
						Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token ?? ""}`
					},
					body: JSON.stringify({
						provider,
						amount: total,
						currency: "USD",
						description: items.map(({ product }) => product.title).join(", "),
						successUrl: `${window.location.origin}/checkout?payment=success`,
						cancelUrl: `${window.location.origin}/checkout?payment=cancelled`
					})
				});
				const payment = await response.json();
				if (!response.ok) throw new Error(payment.error ?? "تعذر بدء الدفع");
				if (!payment.redirectUrl) throw new Error("لم يرسل مزود الدفع رابطًا صالحًا");
				window.location.assign(payment.redirectUrl);
				return;
			}
			const { data: order, error: orderError } = await supabase.from("orders").insert({
				user_id: user.id,
				customer_name: name,
				country,
				total
			}).select("id").single();
			if (orderError) throw orderError;
			const { error: itemsError } = await supabase.from("order_items").insert(items.map(({ product }) => ({
				order_id: order.id,
				product_id: product.id,
				product_title: product.title,
				price: product.price
			})));
			if (itemsError) throw itemsError;
			clear();
			setOrderId(order.id);
			setInvoice(`INV-${order.id.slice(0, 8).toUpperCase()}`);
			setDone(true);
			toast.success("تم تسجيل طلبك بنجاح");
		} catch {
			toast.error("تعذّر حفظ الطلب، حاول مجددًا");
		} finally {
			setBusy(false);
		}
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-14 w-14 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 text-3xl font-bold",
				children: "تم تأكيد طلبك"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted-foreground",
				children: "تم حفظ طلبك في حسابك — يمكنك الوصول إلى منتجاتك من صفحة مشترياتك في أي وقت."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap items-center justify-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/purchases",
						className: "rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90",
						children: "عرض مشترياتي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " التحميل متاح مدى الحياة"]
					}),
					invoice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => window.print(),
						className: "rounded-xl border px-4 py-3 text-sm",
						children: ["طباعة الفاتورة ", invoice]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-8 max-w-md rounded-xl border p-4 text-right",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-semibold",
						children: "طلب إلغاء/استرداد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: refundReason,
						onChange: (e) => setRefundReason(e.target.value),
						className: "mt-2 w-full rounded-lg border p-2",
						placeholder: "اذكر السبب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: async () => {
							if (!refundReason || !user || !orderId) return;
							const { error } = await supabase.from("refund_requests").insert({
								order_id: orderId,
								user_id: user.id,
								reason: refundReason
							});
							toast(error ? "تعذر إرسال الطلب" : "تم إرسال الطلب للمراجعة");
						},
						className: "mt-2 rounded-lg border px-3 py-2 text-sm",
						children: "إرسال الطلب"
					})
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl font-bold",
			children: "إتمام الشراء"
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-8 text-muted-foreground",
			children: [
				"سلتك فارغة.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-primary hover:underline",
					children: "تصفّح المنتجات"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-8 lg:grid-cols-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4 rounded-2xl border border-border bg-card p-6 lg:col-span-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: "بيانات المشتري"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mb-1.5 block text-sm font-medium",
							children: "الاسم الكامل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: name,
							onChange: (e) => setName(e.target.value),
							className: "w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mb-1.5 block text-sm font-medium",
							children: "البريد الإلكتروني"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							readOnly: true,
							value: user.email ?? "",
							type: "email",
							dir: "ltr",
							className: "w-full rounded-xl border border-input bg-muted px-4 py-2.5 text-left text-sm text-muted-foreground outline-none"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-1.5 block text-sm font-medium",
						children: "الدولة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: country,
						onChange: (e) => setCountry(e.target.value),
						className: "w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 rounded-xl bg-muted p-3 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-primary" }), "سيُحفظ طلبك في حسابك فورًا. الدفع الفعلي بالبطاقات يمكن تفعيله لاحقًا."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-semibold",
								children: "طريقة الدفع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex cursor-pointer items-center gap-2 rounded-lg border p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									checked: provider === "manual",
									onChange: () => setProvider("manual")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تسجيل الطلب (بانتظار الدفع)" })]
							}),
							[
								"stripe",
								"paypal",
								"moyasar"
							].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex items-center gap-2 rounded-lg border p-3 ${available[name] ? "cursor-pointer" : "cursor-not-allowed opacity-50"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										disabled: !available[name],
										checked: provider === name,
										onChange: () => setProvider(name)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "capitalize",
										children: name
									}),
									!available[name] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: "(غير مفعّل)"
									})
								]
							}, name)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "لن يتم اعتبار الطلب مدفوعًا قبل تأكيد مزود الدفع. أضف مفاتيح الخادم لتفعيل البطاقات."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: busy,
						className: "w-full rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60",
						children: busy ? "جارٍ المعالجة…" : provider === "manual" ? `تسجيل الطلب · $${total}` : `المتابعة إلى ${provider} · $${total}`
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "h-fit rounded-2xl border border-border bg-card p-6 lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: "ملخص الطلب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-3 text-sm",
						children: items.map(({ product }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: product.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold",
								children: ["$", product.price]
							})]
						}, product.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-between border-t border-border pt-4 font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الإجمالي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["$", total] })]
					})
				]
			})]
		})]
	});
}
//#endregion
export { CheckoutPage as component };
