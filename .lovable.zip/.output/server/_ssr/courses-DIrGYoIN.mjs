import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as PRODUCTS } from "./cart-_EkYk7BO.mjs";
import { t as ProductCard } from "./ProductCard-JSw-7AHV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses-DIrGYoIN.js
var import_jsx_runtime = require_jsx_runtime();
function CoursesPage() {
	const courses = PRODUCTS.filter((p) => p.type === "course");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold",
				children: "الكورسات التدريبية"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted-foreground",
				children: "دورات عملية بالعربية يقدّمها مدرّبون بخبرة ميدانية، مع مشاريع تطبيقية وشهادة إتمام ووصول مدى الحياة."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: courses.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { item }, item.id))
			})
		]
	});
}
//#endregion
export { CoursesPage as component };
