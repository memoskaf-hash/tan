import { r as __toESM } from "../_runtime.mjs";
import { n as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { L as BadgePercent, M as Clock, d as Search, f as Quote, t as Zap, u as ShieldCheck } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PRODUCTS, r as fetchProducts } from "./cart-_EkYk7BO.mjs";
import { t as ProductCard } from "./ProductCard-JSw-7AHV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BRt4y6a3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		key: "all",
		label: "الكل"
	},
	{
		key: "digital",
		label: "منتجات رقمية"
	},
	{
		key: "course",
		label: "كورسات تدريبية"
	}
];
var TESTIMONIALS = [
	{
		name: "ريم العتيبي",
		role: "مصممة واجهات",
		text: "كورس Figma غيّر طريقة عملي بالكامل، صرت أسلّم مشاريعي بنصف الوقت السابق."
	},
	{
		name: "أحمد نصر",
		role: "صاحب متجر إلكتروني",
		text: "كتاب التجارة الإلكترونية عملي جدًا، طبّقت خطواته وحققت أول مبيعات خلال شهر."
	},
	{
		name: "سلمى قاسم",
		role: "مسوّقة رقمية",
		text: "قوالب Notion وفّرت عليّ ساعات أسبوعيًا في تنظيم حملات العملاء."
	}
];
var FAQ = [
	{
		q: "كيف أستلم المنتج بعد الشراء؟",
		a: "تصلك روابط التحميل على بريدك الإلكتروني مباشرة بعد إتمام الدفع، ويبقى الوصول متاحًا دائمًا."
	},
	{
		q: "هل يمكنني استرداد المبلغ؟",
		a: "نعم، لديك 14 يومًا لطلب استرداد كامل إذا لم يكن المحتوى مناسبًا لك."
	},
	{
		q: "هل الكورسات محدّثة؟",
		a: "نحدّث محتوى الكورسات دوريًا، والتحديثات مجانية لمن اشترى الكورس سابقًا."
	},
	{
		q: "هل أحصل على شهادة؟",
		a: "كل كورس تدريبي يمنحك شهادة إتمام بعد إنهاء جميع الوحدات."
	}
];
function Index() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const [products, setProducts] = (0, import_react.useState)(PRODUCTS);
	(0, import_react.useEffect)(() => {
		fetchProducts().then(setProducts);
	}, []);
	const filtered = (0, import_react.useMemo)(() => products.filter((p) => (filter === "all" || p.type === filter) && (p.title.includes(search) || p.description.includes(search))), [
		filter,
		search,
		products
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pt-14 pb-10 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-3xl font-bold leading-snug sm:text-4xl",
					children: ["منتجات رقمية وكورسات تدريبية ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: "بالعربية"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-4 max-w-2xl text-muted-foreground",
					children: "اكتسب مهارات جديدة ووفّر وقتك مع منتجات رقمية عالية الجودة — تحميل فوري بعد الشراء مباشرة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap items-center justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#catalog",
						className: "rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90",
						children: "تصفّح المنتجات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/courses",
						className: "rounded-xl border border-border px-6 py-3 font-semibold transition hover:bg-muted",
						children: "شاهد الكورسات"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "h-4 w-4 text-accent" }), " وصول فوري"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgePercent, { className: "h-4 w-4 text-accent" }), " خصومات دورية"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-accent" }), " وصول مدى الحياة"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-accent" }), " ضمان استرداد 14 يومًا"]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "catalog",
			className: "mx-auto max-w-6xl scroll-mt-24 px-4 pb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex flex-col items-center justify-between gap-4 md:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex rounded-xl bg-muted p-1",
					children: TABS.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setFilter(tab.key),
						className: `rounded-lg px-5 py-2 text-sm font-medium transition ${filter === tab.key ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: tab.label
					}, tab.key))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full md:w-80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "ابحث عن منتج أو كورس...",
						value: search,
						onChange: (e) => setSearch(e.target.value),
						className: "w-full rounded-xl border border-input bg-card py-2.5 pr-10 pl-4 text-sm outline-none focus:ring-2 focus:ring-ring"
					})]
				})]
			}), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-20 text-center text-muted-foreground",
				children: "لا توجد نتائج مطابقة لبحثك."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: filtered.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { item }, item.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border bg-card/50 py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-center text-2xl font-bold",
					children: "ماذا يقول عملاؤنا"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-6 md:grid-cols-3",
					children: TESTIMONIALS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "rounded-2xl border border-border bg-card p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "h-6 w-6 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
								className: "mt-4 text-sm leading-relaxed text-muted-foreground",
								children: t.text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
								className: "mt-4 text-sm font-semibold",
								children: [t.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-normal text-muted-foreground",
									children: t.role
								})]
							})
						]
					}, t.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-3xl px-4 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-center text-2xl font-bold",
				children: "الأسئلة الشائعة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card",
				children: FAQ.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer list-none font-semibold",
						children: item.q
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: item.a
					})]
				}, item.q))
			})]
		})
	] });
}
//#endregion
export { Index as component };
