globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-CAJYyWYN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d09-372ChHSt4eWH3yJZqFyGJ1bbJ6E\"",
		"mtime": "2026-09-07T08:12:38.582Z",
		"size": 3337,
		"path": "../public/assets/about-CAJYyWYN.js"
	},
	"/assets/admin-OmEr5cir.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1377-BSz1H7rpWC6qg2xIu2Z3RySOVNs\"",
		"mtime": "2026-09-07T08:12:38.583Z",
		"size": 4983,
		"path": "../public/assets/admin-OmEr5cir.js"
	},
	"/assets/auth-EOXaKymZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"290f-ee2un30ifpsgdd2aFjFYIc5NBrM\"",
		"mtime": "2026-09-07T08:12:38.584Z",
		"size": 10511,
		"path": "../public/assets/auth-EOXaKymZ.js"
	},
	"/assets/affiliate-Bgr6VfPD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1931-X/0N3T7NbVP0izdA1p0r2v4uP3I\"",
		"mtime": "2026-09-07T08:12:38.584Z",
		"size": 6449,
		"path": "../public/assets/affiliate-Bgr6VfPD.js"
	},
	"/assets/cart-B7SOv6TP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a39-5U+vwFT5fCHjWdBVP/Hk7QnAASY\"",
		"mtime": "2026-09-07T08:12:38.586Z",
		"size": 2617,
		"path": "../public/assets/cart-B7SOv6TP.js"
	},
	"/assets/cart-qz3QEXGO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"229c-Iqm7C6n4aGvDYOYoM1KS/h0Dn4g\"",
		"mtime": "2026-09-07T08:12:38.587Z",
		"size": 8860,
		"path": "../public/assets/cart-qz3QEXGO.js"
	},
	"/assets/checkout-CfhrWcKI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21f3-PGvp6grXl+Dg0CDD4I8btnKlhPo\"",
		"mtime": "2026-09-07T08:12:38.588Z",
		"size": 8691,
		"path": "../public/assets/checkout-CfhrWcKI.js"
	},
	"/assets/circle-check-5cuBJeB_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-oiMDoirKcYfVWjnfoazKKVloRSQ\"",
		"mtime": "2026-09-07T08:12:38.589Z",
		"size": 178,
		"path": "../public/assets/circle-check-5cuBJeB_.js"
	},
	"/assets/clock-p_AiHkzW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-6MC5dkGHTGmFY7ZgHheQUDMKwqw\"",
		"mtime": "2026-09-07T08:12:38.592Z",
		"size": 169,
		"path": "../public/assets/clock-p_AiHkzW.js"
	},
	"/assets/content-CyJqE9e1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b4-y7R0M16DZ3LwZ5ZrG3LtzTmC2Lk\"",
		"mtime": "2026-09-07T08:12:38.598Z",
		"size": 1204,
		"path": "../public/assets/content-CyJqE9e1.js"
	},
	"/assets/contact-DV7Ie5Bt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d3a-377WXePBrlm1dJebs57A1zkf3+s\"",
		"mtime": "2026-09-07T08:12:38.593Z",
		"size": 3386,
		"path": "../public/assets/contact-DV7Ie5Bt.js"
	},
	"/assets/cookies-hKFowGyN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29d-i0jfLe8lJP6KbbcoI7uRc/WU4rs\"",
		"mtime": "2026-09-07T08:12:38.601Z",
		"size": 669,
		"path": "../public/assets/cookies-hKFowGyN.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-07T04:54:02.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/client-ByJHLhN8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"344ca-oJO+wN17fJgc2Q2nP4AXE1SDuZE\"",
		"mtime": "2026-09-07T08:12:38.591Z",
		"size": 214218,
		"path": "../public/assets/client-ByJHLhN8.js"
	},
	"/assets/courses-BdoyMDyg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"313-QYRMceH13Tvzu5cs2qFP7CKvNpw\"",
		"mtime": "2026-09-07T08:12:38.603Z",
		"size": 787,
		"path": "../public/assets/courses-BdoyMDyg.js"
	},
	"/assets/createLucideIcon-CDejS5Oc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c7-yAgGPif2cjUWcneWMzimZwjBY+k\"",
		"mtime": "2026-09-07T08:12:38.607Z",
		"size": 1223,
		"path": "../public/assets/createLucideIcon-CDejS5Oc.js"
	},
	"/assets/jsx-runtime-Cx0BB4qO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"440-7GwVHNgO4EUMk3cR4Bh6KGJPPX4\"",
		"mtime": "2026-09-07T08:12:38.614Z",
		"size": 1088,
		"path": "../public/assets/jsx-runtime-Cx0BB4qO.js"
	},
	"/assets/download-CCoP1ad9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-YkkACTH6dpNqgf/xuz2I0C8LF5c\"",
		"mtime": "2026-09-07T08:12:38.613Z",
		"size": 232,
		"path": "../public/assets/download-CCoP1ad9.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-07T04:54:02.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/lazyRouteComponent-DadIFrwK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"139b-RLBdJAXy+2xoGtQQJhSMTfiZTqs\"",
		"mtime": "2026-09-07T08:12:38.615Z",
		"size": 5019,
		"path": "../public/assets/lazyRouteComponent-DadIFrwK.js"
	},
	"/assets/learning-PYVLPII3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1073-P6YSN3HE8bcWuMJHEyTxsKE/rS0\"",
		"mtime": "2026-09-07T08:12:38.616Z",
		"size": 4211,
		"path": "../public/assets/learning-PYVLPII3.js"
	},
	"/assets/index-BebXWx-F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58a7c-TuoFk33J83fcO9xM1L3t6M+/2nQ\"",
		"mtime": "2026-09-07T08:12:38.580Z",
		"size": 363132,
		"path": "../public/assets/index-BebXWx-F.js"
	},
	"/assets/link-Cw9_XhkI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b6a-lFTi+4PEGuxDJxaEv+mH1pRMKEw\"",
		"mtime": "2026-09-07T08:12:38.624Z",
		"size": 23402,
		"path": "../public/assets/link-Cw9_XhkI.js"
	},
	"/assets/loader-circle-DZCiHoMl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-+vUu3i3Ej64tgT1EMLuoH6MCQ2w\"",
		"mtime": "2026-09-07T08:12:38.632Z",
		"size": 144,
		"path": "../public/assets/loader-circle-DZCiHoMl.js"
	},
	"/assets/mail-i2nzM4Ez.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-1duQJnjpemIZXu7G2amxpE5irz4\"",
		"mtime": "2026-09-07T08:12:38.633Z",
		"size": 213,
		"path": "../public/assets/mail-i2nzM4Ez.js"
	},
	"/assets/membership-CFbsabvR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b14-JdDFudVltLWJNEGfyGnNUEifdBw\"",
		"mtime": "2026-09-07T08:12:38.635Z",
		"size": 2836,
		"path": "../public/assets/membership-CFbsabvR.js"
	},
	"/assets/preload-helper-Czpn1I53.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ac-sE+5KsaRXTMfwOfrOATQajMSGV4\"",
		"mtime": "2026-09-07T08:12:38.636Z",
		"size": 1196,
		"path": "../public/assets/preload-helper-Czpn1I53.js"
	},
	"/assets/privacy-BLcIjfSI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36e-rB58tk7RgtHcD/Wfva1I4bz7dcs\"",
		"mtime": "2026-09-07T08:12:38.637Z",
		"size": 878,
		"path": "../public/assets/privacy-BLcIjfSI.js"
	},
	"/assets/product._slug-B4lWWa7l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bf-cRJm6h1C308+/hArUau5eTeFy/I\"",
		"mtime": "2026-09-07T08:12:38.639Z",
		"size": 447,
		"path": "../public/assets/product._slug-B4lWWa7l.js"
	},
	"/assets/product._slug-D0xPoWC7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bea-0FJDbmjgK4pgubSPHpk5ELSXNGE\"",
		"mtime": "2026-09-07T08:12:38.641Z",
		"size": 7146,
		"path": "../public/assets/product._slug-D0xPoWC7.js"
	},
	"/assets/product._slug-BRHO0aZ0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ae-46lJ547rspy19DkgJgDkY/KKUgY\"",
		"mtime": "2026-09-07T08:12:38.640Z",
		"size": 1710,
		"path": "../public/assets/product._slug-BRHO0aZ0.js"
	},
	"/assets/profile-a-Pf5sGp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1d-UM4/Q0DMxIBRJHR72OjqYUFsM0w\"",
		"mtime": "2026-09-07T08:12:38.645Z",
		"size": 2589,
		"path": "../public/assets/profile-a-Pf5sGp.js"
	},
	"/assets/ProductCard-BMdObjCg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"def-KfOk0+G8USjd9kh9r9HzOD7aUIg\"",
		"mtime": "2026-09-07T08:12:38.581Z",
		"size": 3567,
		"path": "../public/assets/ProductCard-BMdObjCg.js"
	},
	"/assets/purchases-Da8noZXS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ca4-39f8Wn3z8HngYXCsxf3F8gCtH3E\"",
		"mtime": "2026-09-07T08:12:38.647Z",
		"size": 3236,
		"path": "../public/assets/purchases-Da8noZXS.js"
	},
	"/assets/react-3BKWdGy3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d67-7y5khacUeAI0naE7zvk9aPM2omk\"",
		"mtime": "2026-09-07T08:12:38.651Z",
		"size": 7527,
		"path": "../public/assets/react-3BKWdGy3.js"
	},
	"/assets/react-dom-KvMJdSzz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df6-6U6dMppEOVjx81j42FwuC+PpUNo\"",
		"mtime": "2026-09-07T08:12:38.655Z",
		"size": 3574,
		"path": "../public/assets/react-dom-KvMJdSzz.js"
	},
	"/assets/refunds-Dh7QKRCi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"346-c+xSHbyDhzS+s/blNlGZLgjQ7e0\"",
		"mtime": "2026-09-07T08:12:38.707Z",
		"size": 838,
		"path": "../public/assets/refunds-Dh7QKRCi.js"
	},
	"/assets/routes-HFfwRPAk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c8b-MpbwrAdx5/uHD3WtVpB3zrKkSI0\"",
		"mtime": "2026-09-07T08:12:38.708Z",
		"size": 7307,
		"path": "../public/assets/routes-HFfwRPAk.js"
	},
	"/assets/terms-BcWPZk5N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36a-JFYHbOum+51R3xUCpdnRWxIsOVM\"",
		"mtime": "2026-09-07T08:12:38.710Z",
		"size": 874,
		"path": "../public/assets/terms-BcWPZk5N.js"
	},
	"/assets/useNavigate-DIoXezsG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-EcpiO1LDK9cgWmswbF3Cem/Y/rw\"",
		"mtime": "2026-09-07T08:12:38.711Z",
		"size": 251,
		"path": "../public/assets/useNavigate-DIoXezsG.js"
	},
	"/assets/users-BaB8Xz7K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-JCtUmov3vxDGI5kq7vd2oNqS7J4\"",
		"mtime": "2026-09-07T08:12:38.713Z",
		"size": 306,
		"path": "../public/assets/users-BaB8Xz7K.js"
	},
	"/assets/styles-Bco6VUQM.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"138a4-QsFgAZy5YKILd7elUNIZa2QWlGM\"",
		"mtime": "2026-09-07T08:12:38.714Z",
		"size": 80036,
		"path": "../public/assets/styles-Bco6VUQM.css"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_DMV7_W = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_DMV7_W
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
