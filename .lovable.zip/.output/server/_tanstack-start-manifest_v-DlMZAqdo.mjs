//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DlMZAqdo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/affiliate",
			"/auth",
			"/cart",
			"/checkout",
			"/contact",
			"/content",
			"/cookies",
			"/courses",
			"/learning",
			"/membership",
			"/privacy",
			"/profile",
			"/purchases",
			"/refunds",
			"/terms",
			"/api/affiliate-click",
			"/api/affiliate-conversion",
			"/api/affiliate-referral",
			"/api/chat",
			"/api/download",
			"/api/payment-webhooks",
			"/api/payments",
			"/api/payouts",
			"/product/$slug"
		],
		preloads: [
			"/assets/index-BebXWx-F.js",
			"/assets/jsx-runtime-Cx0BB4qO.js",
			"/assets/react-3BKWdGy3.js",
			"/assets/react-dom-KvMJdSzz.js",
			"/assets/link-Cw9_XhkI.js",
			"/assets/product._slug-BRHO0aZ0.js",
			"/assets/lazyRouteComponent-DadIFrwK.js",
			"/assets/useNavigate-DIoXezsG.js",
			"/assets/client-ByJHLhN8.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/cart-qz3QEXGO.js",
			"/assets/createLucideIcon-CDejS5Oc.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BebXWx-F.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-HFfwRPAk.js",
			"/assets/clock-p_AiHkzW.js",
			"/assets/ProductCard-BMdObjCg.js"
		]
	},
	"/about": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CAJYyWYN.js", "/assets/users-BaB8Xz7K.js"]
	},
	"/admin": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-OmEr5cir.js"]
	},
	"/affiliate": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/affiliate.tsx",
		children: void 0,
		preloads: ["/assets/affiliate-Bgr6VfPD.js"]
	},
	"/auth": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-EOXaKymZ.js", "/assets/mail-i2nzM4Ez.js"]
	},
	"/cart": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/cart.tsx",
		children: void 0,
		preloads: ["/assets/cart-B7SOv6TP.js"]
	},
	"/checkout": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-CfhrWcKI.js",
			"/assets/circle-check-5cuBJeB_.js",
			"/assets/download-CCoP1ad9.js",
			"/assets/loader-circle-DZCiHoMl.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-DV7Ie5Bt.js",
			"/assets/circle-check-5cuBJeB_.js",
			"/assets/clock-p_AiHkzW.js",
			"/assets/mail-i2nzM4Ez.js"
		]
	},
	"/content": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/content.tsx",
		children: void 0,
		preloads: ["/assets/content-CyJqE9e1.js"]
	},
	"/cookies": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/cookies.tsx",
		children: void 0,
		preloads: ["/assets/cookies-hKFowGyN.js"]
	},
	"/courses": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/courses.tsx",
		children: void 0,
		preloads: ["/assets/courses-BdoyMDyg.js", "/assets/ProductCard-BMdObjCg.js"]
	},
	"/learning": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/learning.tsx",
		children: void 0,
		preloads: ["/assets/learning-PYVLPII3.js"]
	},
	"/membership": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/membership.tsx",
		children: void 0,
		preloads: ["/assets/membership-CFbsabvR.js"]
	},
	"/privacy": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-BLcIjfSI.js"]
	},
	"/profile": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-a-Pf5sGp.js"]
	},
	"/purchases": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/purchases.tsx",
		children: void 0,
		preloads: [
			"/assets/purchases-Da8noZXS.js",
			"/assets/download-CCoP1ad9.js",
			"/assets/loader-circle-DZCiHoMl.js"
		]
	},
	"/refunds": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/refunds.tsx",
		children: void 0,
		preloads: ["/assets/refunds-Dh7QKRCi.js"]
	},
	"/terms": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-BcWPZk5N.js"]
	},
	"/product/$slug": {
		filePath: "C:/Users/OMAR ALSHAHER/Desktop/احدث نسخة/احدث نسخة/page-tweaker-pro-main/src/routes/product.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/product._slug-B4lWWa7l.js",
			"/assets/product._slug-D0xPoWC7.js",
			"/assets/circle-check-5cuBJeB_.js",
			"/assets/clock-p_AiHkzW.js",
			"/assets/download-CCoP1ad9.js",
			"/assets/ProductCard-BMdObjCg.js",
			"/assets/users-BaB8Xz7K.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
