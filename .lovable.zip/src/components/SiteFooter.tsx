import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3">
        <div>
          <h2 className="text-base font-bold">جود</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            منتجات رقمية وكورسات تدريبية بالعربية، بتحميل فوري ودفع آمن.
          </p>
        </div>
        <div>
          <h3 className="text-sm font-semibold">روابط سريعة</h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-foreground">الرئيسية</Link></li>
            <li><Link to="/courses" className="hover:text-foreground">الكورسات</Link></li>
            <li><Link to="/about" className="hover:text-foreground">من نحن</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">تواصل معنا</Link></li>
            <li><Link to="/privacy" className="hover:text-foreground">الخصوصية</Link></li>
            <li><Link to="/terms" className="hover:text-foreground">الشروط</Link></li>
            <li><Link to="/refunds" className="hover:text-foreground">الاسترداد</Link></li>
            <li><Link to="/cookies" className="hover:text-foreground">ملفات الارتباط</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-semibold">الدعم</h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li>ضمان استرداد خلال 14 يومًا</li>
            <li>دعم فني عبر البريد الإلكتروني</li>
            <li>تحديثات مجانية للمنتجات</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-6 text-center text-sm text-muted-foreground">
        جميع الحقوق محفوظة © {new Date().getFullYear()} جود
      </div>
    </footer>
  );
}
