import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search, ShieldCheck, Zap, BadgePercent, Clock, Quote } from "lucide-react";
import { PRODUCTS, fetchProducts, type Product } from "@/lib/products";
import { ProductCard } from "@/components/ProductCard";

const TABS = [
  { key: "all", label: "الكل" },
  { key: "digital", label: "منتجات رقمية" },
  { key: "course", label: "كورسات تدريبية" },
] as const;

const TESTIMONIALS = [
  {
    name: "ريم العتيبي",
    role: "مصممة واجهات",
    text: "كورس Figma غيّر طريقة عملي بالكامل، صرت أسلّم مشاريعي بنصف الوقت السابق.",
  },
  {
    name: "أحمد نصر",
    role: "صاحب متجر إلكتروني",
    text: "كتاب التجارة الإلكترونية عملي جدًا، طبّقت خطواته وحققت أول مبيعات خلال شهر.",
  },
  {
    name: "سلمى قاسم",
    role: "مسوّقة رقمية",
    text: "قوالب Notion وفّرت عليّ ساعات أسبوعيًا في تنظيم حملات العملاء.",
  },
];

const FAQ = [
  {
    q: "كيف أستلم المنتج بعد الشراء؟",
    a: "تصلك روابط التحميل على بريدك الإلكتروني مباشرة بعد إتمام الدفع، ويبقى الوصول متاحًا دائمًا.",
  },
  {
    q: "هل يمكنني استرداد المبلغ؟",
    a: "نعم، لديك 14 يومًا لطلب استرداد كامل إذا لم يكن المحتوى مناسبًا لك.",
  },
  {
    q: "هل الكورسات محدّثة؟",
    a: "نحدّث محتوى الكورسات دوريًا، والتحديثات مجانية لمن اشترى الكورس سابقًا.",
  },
  {
    q: "هل أحصل على شهادة؟",
    a: "كل كورس تدريبي يمنحك شهادة إتمام بعد إنهاء جميع الوحدات.",
  },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "جود | منتجات رقمية وكورسات تدريبية" },
      {
        name: "description",
        content:
          "تصفح منتجاتنا الرقمية وكورساتنا التدريبية بالعربية: قوالب، كتب إلكترونية، ودورات احترافية بأسعار منافسة وتحميل فوري.",
      },
      { property: "og:title", content: "جود | منتجات رقمية وكورسات تدريبية" },
      {
        property: "og:description",
        content: "قوالب، كتب إلكترونية، ودورات احترافية بالعربية — تحميل فوري ودفع آمن.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [filter, setFilter] = useState<(typeof TABS)[number]["key"]>("all");
  const [search, setSearch] = useState("");
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  useEffect(() => { fetchProducts().then(setProducts); }, []);

  const filtered = useMemo(
    () =>
      products.filter(
        (p) =>
          (filter === "all" || p.type === filter) &&
          (p.title.includes(search) || p.description.includes(search)),
      ),
    [filter, search, products],
  );

  return (
    <>
      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 pt-14 pb-10 text-center">
        <h1 className="text-3xl font-bold leading-snug sm:text-4xl">
          منتجات رقمية وكورسات تدريبية <span className="text-primary">بالعربية</span>
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
          اكتسب مهارات جديدة ووفّر وقتك مع منتجات رقمية عالية الجودة — تحميل فوري بعد الشراء مباشرة.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a
            href="#catalog"
            className="rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90"
          >
            تصفّح المنتجات
          </a>
          <Link
            to="/courses"
            className="rounded-xl border border-border px-6 py-3 font-semibold transition hover:bg-muted"
          >
            شاهد الكورسات
          </Link>
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-accent" /> وصول فوري
          </span>
          <span className="flex items-center gap-2">
            <BadgePercent className="h-4 w-4 text-accent" /> خصومات دورية
          </span>
          <span className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-accent" /> وصول مدى الحياة
          </span>
          <span className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-accent" /> ضمان استرداد 14 يومًا
          </span>
        </div>
      </section>

      {/* Catalog */}
      <section id="catalog" className="mx-auto max-w-6xl scroll-mt-24 px-4 pb-16">
        <div className="mb-8 flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex rounded-xl bg-muted p-1">
            {TABS.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key)}
                className={`rounded-lg px-5 py-2 text-sm font-medium transition ${
                  filter === tab.key
                    ? "bg-card text-primary shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-80">
            <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="ابحث عن منتج أو كورس..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-input bg-card py-2.5 pr-10 pl-4 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <p className="py-20 text-center text-muted-foreground">لا توجد نتائج مطابقة لبحثك.</p>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filtered.map((item) => (
              <ProductCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </section>

      {/* Testimonials */}
      <section className="border-y border-border bg-card/50 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-center text-2xl font-bold">ماذا يقول عملاؤنا</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {TESTIMONIALS.map((t) => (
              <figure key={t.name} className="rounded-2xl border border-border bg-card p-6">
                <Quote className="h-6 w-6 text-primary" />
                <blockquote className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {t.text}
                </blockquote>
                <figcaption className="mt-4 text-sm font-semibold">
                  {t.name}
                  <span className="block text-xs font-normal text-muted-foreground">{t.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-4 py-16">
        <h2 className="text-center text-2xl font-bold">الأسئلة الشائعة</h2>
        <div className="mt-8 divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card">
          {FAQ.map((item) => (
            <details key={item.q} className="group px-6 py-4">
              <summary className="cursor-pointer list-none font-semibold">{item.q}</summary>
              <p className="mt-3 text-sm text-muted-foreground">{item.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
