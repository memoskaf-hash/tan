import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import type { Product } from "@/lib/products";
export const Route = createFileRoute("/admin")({ component: Admin });
function Admin() {
  const { user, loading } = useAuth(); const [items, setItems] = useState<Product[]>([]); const [title, setTitle] = useState(""); const [price, setPrice] = useState("0"); const [orders, setOrders] = useState<{ id: string; customer_name: string; total: number; status: string }[]>([]); const [contentTitle, setContentTitle] = useState(""); const [contentBody, setContentBody] = useState("");
  const authorized = user?.app_metadata?.role === "admin" || user?.app_metadata?.role === "super_admin";
  useEffect(() => {
    if (!loading && authorized) {
      supabase.from("products").select("*").then(({ data }) => setItems((data ?? []) as Product[]));
      supabase.from("orders").select("id,customer_name,total,status").order("created_at", { ascending: false }).then(({ data }) => setOrders(data ?? []));
    }
  }, [authorized, loading]);
  async function create() { const { data } = await supabase.from("products").insert({ slug: title.toLowerCase().replace(/\s+/g, "-"), title, description: title, long_description: title, price: Number(price), type: "digital", features: [], curriculum: [], instructor: "Store", rating: 5, students: 0 }).select().single(); if (data) setItems([...items, data as Product]); setTitle(""); }
  async function remove(id: string) { await supabase.from("products").delete().eq("id", id); setItems(items.filter(x => x.id !== id)); }
  async function publishContent() { if (!contentTitle || !contentBody) return; const { error } = await (supabase as any).from("content_pages").upsert({ slug: contentTitle.toLowerCase().replace(/\s+/g, "-"), title: contentTitle, body: contentBody, published: true }); if (!error) { setContentTitle(""); setContentBody(""); alert("تم نشر المحتوى"); } else alert("تعذر النشر؛ شغّل migration المنصة أولاً."); }
  if (loading) return <div className="mx-auto max-w-4xl px-4 py-12">جارٍ التحقق من الصلاحيات…</div>;
  if (!authorized) return <div className="mx-auto max-w-4xl px-4 py-12 text-center text-destructive">غير مصرح لك بالوصول إلى لوحة الإدارة.</div>;
  const revenue = orders.filter((o) => o.status === "confirmed" || o.status === "paid").reduce((sum, o) => sum + Number(o.total), 0);
  return <div className="mx-auto max-w-6xl px-4 py-12"><h1 className="mb-6 text-2xl font-bold">لوحة الإدارة</h1>
    <div className="mb-8 grid gap-3 sm:grid-cols-3"><div className="rounded-xl border bg-card p-4"><span className="text-sm text-muted-foreground">المنتجات</span><strong className="mt-1 block text-2xl">{items.length}</strong></div><div className="rounded-xl border bg-card p-4"><span className="text-sm text-muted-foreground">الطلبات</span><strong className="mt-1 block text-2xl">{orders.length}</strong></div><div className="rounded-xl border bg-card p-4"><span className="text-sm text-muted-foreground">المبيعات المؤكدة</span><strong className="mt-1 block text-2xl">${revenue.toFixed(2)}</strong></div></div>
    <section><h2 className="mb-3 text-lg font-bold">إدارة المنتجات</h2><div className="mb-6 flex flex-wrap gap-2"><input placeholder="اسم المنتج" value={title} onChange={e=>setTitle(e.target.value)} className="rounded-lg border p-2" /><input placeholder="السعر" value={price} onChange={e=>setPrice(e.target.value)} className="w-24 rounded-lg border p-2" /><button onClick={create} className="rounded-lg bg-primary px-4 text-primary-foreground">إضافة</button></div><div className="space-y-2">{items.map(item=><div key={item.id} className="flex justify-between rounded-lg border p-3">{item.title}<button onClick={()=>remove(item.id)} className="text-destructive">حذف</button></div>)}</div></section>
    <section className="mt-10"><h2 className="mb-3 text-lg font-bold">آخر الطلبات والعملاء</h2><div className="overflow-x-auto rounded-xl border"><table className="w-full text-sm"><thead><tr className="border-b text-right"><th className="p-3">العميل</th><th className="p-3">المبلغ</th><th className="p-3">الحالة</th></tr></thead><tbody>{orders.map((order)=><tr key={order.id} className="border-b last:border-0"><td className="p-3">{order.customer_name}</td><td className="p-3">${order.total}</td><td className="p-3">{order.status}</td></tr>)}</tbody></table></div></section>
    <section className="mt-10 rounded-xl border bg-card p-5"><h2 className="mb-3 text-lg font-bold">تحرير المقالات والأسئلة الشائعة</h2><input value={contentTitle} onChange={e=>setContentTitle(e.target.value)} placeholder="العنوان" className="mb-2 w-full rounded-lg border p-2"/><textarea value={contentBody} onChange={e=>setContentBody(e.target.value)} placeholder="المحتوى" className="min-h-28 w-full rounded-lg border p-2"/><button onClick={publishContent} className="mt-2 rounded-lg bg-primary px-4 py-2 text-primary-foreground">نشر الصفحة</button></section>
  </div>;
}
